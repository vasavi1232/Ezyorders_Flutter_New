import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/constants/app_theme.dart';
import '../../../../core/constants/url_api_key.dart';
import '../../../../core/network/image_cache_manager.dart';
import '../../../../core/utils/common_methods.dart';
import '../../../../data/models/home_models.dart';
import '../../products/product_details_screen.dart';

class WishlistItemWidget extends StatelessWidget {
  final ProductItem item;
  final VoidCallback? onAddToCart;
  final VoidCallback? onDelete;
  final VoidCallback? onTap;
  final VoidCallback? onSelect;
  final double? width;
  final bool isSelected;
  final String? categoryName;
  final int? selectedQuantity;
  final VoidCallback? onIncrementQuantity;
  final VoidCallback? onDecrementQuantity;

  const WishlistItemWidget({
    super.key,
    required this.item,
    this.onAddToCart,
    this.onDelete,
    this.onTap,
    this.onSelect,
    this.width,
    this.isSelected = false,
    this.categoryName,
    this.selectedQuantity,
    this.onIncrementQuantity,
    this.onDecrementQuantity,
  });

  @override
  Widget build(BuildContext context) {
    // Logic Parity with Android Fav_ProductslistAdapter.kt

    final bool isOutOfStock = item.qtyStatus == "Out Of Stock";
    final bool canAddToCart = item.supplierAvailable == "1" &&
        item.productAvailable == "1" &&
        !isOutOfStock;
    final bool hasPromotion = item.hasPromotion == "Yes" &&
        item.promotionPrice != null &&
        double.tryParse(item.promotionPrice ?? "0")! > 0;

    // Determine category name to display (Parity: Show if 'All' categories selected)
    // For now, allow it to be passed in or just show it if available.
    // Provider logic handles filtering, but Widget might need to know "current context".
    // Android shows it if `favCategoty == ""`

    return Container(
      width: width,
      margin:
          EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h), // List spacing
      child: Card(
        elevation: 1,
        color: Colors.white,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(2.r),
        ),
        child: InkWell(
          onTap: onTap ??
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        ProductDetailsScreen(productId: item.productId!),
                  ),
                );
              },
          child: Padding(
            padding: EdgeInsets.all(8.0.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 1. Checkbox
                    // Using a custom container to match look or standard Checkbox
                    SizedBox(
                      width: 24.w,
                      height: 24.w,
                      child: Checkbox(
                        value: isSelected,
                        onChanged: (val) {
                          if (onSelect != null) onSelect!();
                        },
                        activeColor: AppTheme.tealColor,
                        side: BorderSide(color: Colors.grey, width: 1.5),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(2)),
                      ),
                    ),
                    SizedBox(width: 8.w),

                    // 2. Image
                    Container(
                      height: 80.h,
                      width: 80.w,
                      alignment: Alignment.center,
                      child: _buildImage(item.image),
                    ),
                    SizedBox(width: 10.w),

                    // 3. Details Column
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            CommonMethods.decodeHtmlEntities(item.brandName),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: AppTheme.darkerGrayColor,
                                fontSize: 12.sp,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            CommonMethods.decodeHtmlEntities(item.title),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: AppTheme.textColor,
                                fontSize: 13.sp,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 5.h),
                          // Price Section
                          if (!hasPromotion) ...[
                            Text(
                              _formatPrice(item.price),
                              style: TextStyle(
                                  color: AppTheme.darkerGrayColor,
                                  fontSize: 14.sp),
                            ),
                          ] else ...[
                            // Formatting for promo
                            Text(
                              _formatPrice(item.promotionPrice),
                              style: TextStyle(
                                  color: AppTheme.darkerGrayColor,
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w500),
                            ),
                            SizedBox(height: 2.h),
                            Row(
                              children: [
                                Text(
                                  _formatPrice(item.price),
                                  style: TextStyle(
                                      color: AppTheme.primaryColor,
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.bold,
                                      decorationThickness: 1.5,
                                      decoration: TextDecoration.lineThrough),
                                ),
                                SizedBox(width: 5.w),
                                Builder(
                                  builder: (context) {
                                    double original =
                                        double.tryParse(item.price ?? "0") ?? 0;
                                    double promo = double.tryParse(
                                            item.promotionPrice ?? "0") ??
                                        0;
                                    String discountStr = "";
                                      discountStr =
                                          "-${CommonMethods.calculateDiscount(item.price, item.promotionPrice)}%";
                                    if (discountStr.isEmpty) {
                                      return const SizedBox.shrink();
                                    }
                                    return Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 4.w, vertical: 2.h),
                                      decoration: BoxDecoration(
                                        color: AppTheme.redColor,
                                        borderRadius:
                                            BorderRadius.circular(4.r),
                                      ),
                                      child: Text(
                                        discountStr,
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 10.sp,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ],
                            )
                          ],
                        ],
                      ),
                    ),

                    // 4. Delete Icon (Heart Red)
                    InkWell(
                      onTap: onDelete,
                      child: Padding(
                        padding: EdgeInsets.all(5.w),
                        child: Icon(
                          Icons.favorite, // Filled Red Heart logic
                          color: AppTheme.redColor,
                          size: 24.sp,
                        ),
                      ),
                    )
                  ],
                ),

                SizedBox(height: 10.h),

                // Bottom Row: Button OR Quantity Editing Layout
                if (isSelected)
                  // Quantity and Sub Total Layout
                  Container(
                    width: width,
                    margin: EdgeInsets.symmetric(vertical: 5.h),
                    decoration: BoxDecoration(
                      color: AppTheme.white,
                      borderRadius: BorderRadius.circular(4.r),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Quantity Controls
                        Container(
                          height: 35.h,
                          width: 110.w,
                          decoration: BoxDecoration(
                            border: Border.all(color: AppTheme.borderColor),
                            borderRadius: BorderRadius.circular(4.r),
                            color: AppTheme.white,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              InkWell(
                                onTap: onDecrementQuantity,
                                child: Container(
                                  width: 30.w,
                                  alignment: Alignment.center,
                                  child: Text(
                                    "-",
                                    style: TextStyle(
                                      fontSize: 22.sp,
                                      color: Colors.black54,
                                    ),
                                  ),
                                ),
                              ),
                              VerticalDivider(
                                width: 1,
                                thickness: 1,
                                color: AppTheme.hintColor,
                              ),
                              Expanded(
                                child: Container(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "${selectedQuantity ?? 1}",
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                      color: Colors.black54,
                                    ),
                                  ),
                                ),
                              ),
                              VerticalDivider(
                                width: 1,
                                thickness: 1,
                                color: AppTheme.hintColor,
                              ),
                              InkWell(
                                onTap: onIncrementQuantity,
                                child: Container(
                                  width: 30.w,
                                  alignment: Alignment.center,
                                  child: Text(
                                    "+",
                                    style: TextStyle(
                                      fontSize: 22.sp,
                                      color: Colors.black54,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        
                        // Sub Total
                        Row(
                          children: [
                            Text(
                              "Sub Total : ",
                              style: TextStyle(
                                color: AppTheme.blackColor,
                                fontSize: 13.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Builder(
                              builder: (context) {
                                double basePrice = double.tryParse(item.price ?? "0") ?? 0.0;
                                if (item.hasPromotion == "Yes" && item.promotionPrice != null) {
                                  basePrice = double.tryParse(item.promotionPrice!) ?? basePrice;
                                }
                                double subtotal = basePrice * (selectedQuantity ?? 1);
                                return Text(
                                  _formatPrice(subtotal.toString()),
                                  style: TextStyle(
                                    color: AppTheme.primaryColor,
                                    fontSize: 13.sp,
                                  ),
                                );
                              },
                            )
                          ],
                        )
                      ],
                    ),
                  )
                else
                  // Standard Button Layout
                  Row(
                    children: [
                      // Button
                      InkWell(
                        onTap: canAddToCart ? onAddToCart : null,
                        child: Container(
                          height: 32.h,
                          padding: EdgeInsets.symmetric(horizontal: 15.w),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              color: canAddToCart
                                  ? AppTheme.tealColor
                                  : AppTheme.redColor,
                              borderRadius: BorderRadius.circular(20.r),
                              boxShadow: [
                                BoxShadow(
                                    color: AppTheme.shadowBlack,
                                    blurRadius: 4,
                                    offset: Offset(0, 2))
                              ]),
                          child: Text(
                            isOutOfStock
                                ? "Out Of Stock"
                                : (item.addedToCart == "Yes"
                                    ? "Update Cart [${item.addedQty ?? '1'}]"
                                    : "Add To Cart"),
                            style: TextStyle(
                                fontSize: 11.sp,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ),
                if (categoryName != null && categoryName!.isNotEmpty)
                  Padding(
                    padding: EdgeInsets.only(top: 5.h),
                    child: Text(
                      "[$categoryName]",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _formatPrice(String? price) {
    return CommonMethods.setPriceFormatString(price);
  }

  Widget _buildImage(String? path) {
    if (path == null || path.isEmpty) {
      return Container(color: Colors.grey[200]);
    }
    String finalUrl = path;
    if (!path.startsWith("http")) {
      finalUrl = "${UrlApiKey.mainUrl}$path";
    }

    return CachedNetworkImage(
      imageUrl: finalUrl,
      height: 120.h,
      fit: BoxFit.contain,
      cacheManager: ImageCacheManager(),
      placeholder: (context, url) => Container(color: Colors.grey[200]),
      errorWidget: (context, url, error) =>
          const Icon(Icons.broken_image, color: Colors.grey),
    );
  }
}
