import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../data/models/cart_models.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../../../core/constants/app_theme.dart';
import 'package:ezy_orders_flutter/core/utils/common_methods.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/constants/url_api_key.dart';
import '../../../widgets/custom_loader_widget.dart';
import 'package:provider/provider.dart';
import '../../../providers/dashboard_provider.dart';

class CartItemRefinedWidget extends StatelessWidget {
  final CartProduct item;
  final bool showHeader;
  final String brandName;
  final String brandId;
  final Function(String newQty) onUpdateQty;
  final VoidCallback onDelete;

  const CartItemRefinedWidget({
    super.key,
    required this.item,
    this.showHeader = false,
    required this.brandName,
    required this.brandId,
    required this.onUpdateQty,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    // Parsing Qty safely
    int qty = int.tryParse(item.qty?.toString() ?? "0") ?? 0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (showHeader) _buildHeader(context),
        Container(
          margin: EdgeInsets.only(bottom: 8.h),
          padding: EdgeInsets.all(5.w),
          color: Colors.white,
          child: Column(
            children: [
              Card(
                elevation: 3,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5.r)),
                margin: EdgeInsets.all(5.w),
                child: Padding(
                  padding: EdgeInsets.all(10.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Brand Row
                      Text(
                        CommonMethods.decodeHtmlEntities(brandName),
                        style: TextStyle(
                            color: AppTheme.primaryColor,
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w800),
                      ),
                      SizedBox(height: 5.h),

                      // Image, Info, and Delete Row
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Image
                          Container(
                            width: 70.w,
                            height: 70.h,
                            alignment: Alignment.center,
                            child: _buildImage(item.image),
                          ),
                          SizedBox(width: 15.w),

                          // Center Details
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  CommonMethods.decodeHtmlEntities(
                                      item.title?.toUpperCase() ?? ""),
                                  style: TextStyle(
                                      color: AppTheme.textColor,
                                      fontSize: 13.sp,
                                      fontWeight: FontWeight.bold),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                SizedBox(height: 5.h),

                                // Price Section
                                // Match native Android: show strikethrough if salePrice < normalPrice
                                if (() {
                                  double n = double.tryParse(item.normalPrice ?? "0") ?? 0;
                                  double s = double.tryParse(item.salePrice ?? "0") ?? 0;
                                  return s > 0 && s < n;
                                }()) ...[
                                  Text(
                                    CommonMethods.setPriceFormatString(
                                        item.normalPrice),
                                    style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 13.sp,
                                        decoration: TextDecoration.lineThrough,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                                Text(
                                  CommonMethods.setPriceFormatString(
                                      (double.tryParse(item.salePrice ?? "0") ??
                                                  0) >
                                              0
                                          ? item.salePrice
                                          : item.normalPrice),
                                  style: TextStyle(
                                      color: AppTheme.darkerGrayColor,
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.bold),
                                ),

                                if (() {
                                  double n = double.tryParse(item.normalPrice ?? "0") ?? 0;
                                  double s = double.tryParse(item.salePrice ?? "0") ?? 0;
                                  return s > 0 && s < n;
                                }())
                                  Container(
                                    margin: EdgeInsets.only(top: 5.h),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 5.w, vertical: 2.h),
                                    color: AppTheme.redColor,
                                    child: Text(
                                      "-${CommonMethods.calculateDiscount(item.normalPrice, item.salePrice)}%",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 12.sp,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                              ],
                            ),
                          ),

                          // Delete Icon
                          InkWell(
                            onTap: onDelete,
                            child: Padding(
                              padding: EdgeInsets.all(5.w),
                              child: Icon(Icons.delete,
                                  color: AppTheme.redColor, size: 24.sp),
                            ),
                          ),
                        ],
                      ),

                      // Bottom Row: Ordered As and Qty
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Ordered As
                          Consumer<DashboardProvider>(
                            builder: (context, dashboard, child) {
                              final bool showSoldAs = dashboard
                                      .profileResponse?.results?[0]?.showSoldAs ==
                                  "Yes";
                              if (!showSoldAs) return const SizedBox.shrink();

                              if (item.orderedAs != null &&
                                  item.orderedAs!.isNotEmpty) {
                                return Padding(
                                  padding: EdgeInsets.only(top: 10.h),
                                  child: Row(
                                    children: [
                                      Text("Ordered As : ",
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 13.sp,
                                              fontWeight: FontWeight.w800)),
                                      Text(item.orderedAs ?? item.soldAs ?? "Each",
                                          style: TextStyle(
                                              color: AppTheme.primaryColor,
                                              fontSize: 13.sp,
                                              fontWeight: FontWeight.bold)),
                                    ],
                                  ),
                                );
                              }
                              return const SizedBox.shrink();
                            },
                          ),

                          // Qty Control Box
                          Container(
                            width: 100.w,
                            height: 35.h,
                            margin: EdgeInsets.only(top: 10.h),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(color: AppTheme.borderColor),
                              borderRadius: BorderRadius.circular(5.r),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: InkWell(
                                    onTap: () {
                                      if (qty > 1) {
                                        onUpdateQty((qty - 1).toString());
                                      }
                                    },
                                    child: Center(
                                        child: Text("-",
                                            style: TextStyle(
                                                fontSize: 20.sp,
                                                color:
                                                    AppTheme.darkGrayColor))),
                                  ),
                                ),
                                Container(
                                    width: 1.w, color: Colors.grey.shade400),
                                Expanded(
                                  child: Center(
                                      child: Text("$qty",
                                          style: TextStyle(
                                              fontSize: 14.sp,
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold))),
                                ),
                                Container(
                                    width: 1.w, color: Colors.grey.shade400),
                                  Expanded(
                                    child: InkWell(
                                      onTap: () {
                                        // Stock Validation logic matching ProductDetailsBottomSheet
                                        int maxQty = 1000;
                                        if (item.stockUnlimited != "Yes" &&
                                            item.qtyStatus !=
                                                "Low In Stock") {
                                          maxQty = int.tryParse(item
                                                  .availableStockQty
                                                  .toString()) ??
                                              1000;
                                        }

                                        if (qty < maxQty) {
                                          onUpdateQty((qty + 1).toString());
                                        } else {
                                          Fluttertoast.showToast(
                                              msg:
                                                  "Only $maxQty items available in stock");
                                        }
                                      },
                                      child: Center(
                                        child: Text("+",
                                            style: TextStyle(
                                                fontSize: 20.sp,
                                                color:
                                                    AppTheme.darkGrayColor))),
                                      ),
                                    ),
                                  ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildHeader(BuildContext context) {
    return SizedBox.shrink();
  }

  Widget _buildImage(String? path) {
    if (path == null || path.isEmpty) {
      return Icon(Icons.image_not_supported, color: Colors.grey);
    }
    String finalUrl = path;
    if (!path.startsWith("http")) {
      finalUrl = "${UrlApiKey.mainUrl}$path";
    }

    return CachedNetworkImage(
      imageUrl: finalUrl,
      fit: BoxFit.contain,
      placeholder: (context, url) =>
          Center(child: CustomLoaderWidget(size: 30.w)),
      errorWidget: (context, url, error) =>
          Icon(Icons.broken_image, color: Colors.grey),
    );
  }
}
