import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/utils/common_methods.dart';
import '../../../providers/checkout_provider.dart';
import '../../../providers/dashboard_provider.dart';
import '../../../../core/constants/app_theme.dart';
import '../../../widgets/custom_loader_widget.dart';

class StepPreviewWidget extends StatelessWidget {
  const StepPreviewWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CheckoutProvider>();
    // Use cartResult.brands for grouped items, fallback to cartItems if empty
    final brands = provider.cartResult?.brands;
    final flatItems = provider.cartItems;
    final hasBrands = brands != null && brands.isNotEmpty;

    return Column(
      children: [
        // Scrollable Content
        Expanded(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(16.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // 1. Order Details Card
                _buildCard(
                  context,
                  title: "Order Details",
                  onEdit: () => provider.goToStep(0), // Go to Cart
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Items Header
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Items",
                              style: TextStyle(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey.shade600)),
                          Text("Qty",
                              style: TextStyle(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue.shade900)),
                        ],
                      ),
                      SizedBox(height: 10.h),
                      const Divider(),

                      // Grouped Items (by Brand) OR Flat list
                      if (hasBrands)
                        ...brands.map((brand) {
                          if (brand == null || brand.products == null)
                            return const SizedBox.shrink();
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 10.h),
                              Text(
                                brand.brandName ?? "Unknown Vendor",
                                style: TextStyle(
                                    fontSize: 13.sp,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey.shade800),
                              ),
                              SizedBox(height: 5.h),
                              Container(
                                decoration: BoxDecoration(
                                  border:
                                      Border.all(color: AppTheme.borderColor),
                                  borderRadius: BorderRadius.circular(4.r),
                                ),
                                child: Column(
                                  children: brand.products!.map((product) {
                                    if (product == null)
                                      return const SizedBox.shrink();
                                    return Padding(
                                      padding: EdgeInsets.all(8.w),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  product.title ?? "",
                                                  style: TextStyle(
                                                      fontSize: 14.sp,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: AppTheme
                                                          .primaryColor),
                                                ),
                                                SizedBox(height: 4.h),
                                                Text(
                                                  CommonMethods
                                                      .setPriceFormatString(
                                                          product.salePrice),
                                                  style: TextStyle(
                                                      fontSize: 13.sp,
                                                      color:
                                                          Colors.grey.shade700),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            "${product.qty}",
                                            style: TextStyle(
                                                fontSize: 14.sp,
                                                fontWeight: FontWeight.bold,
                                                color: AppTheme.primaryColor),
                                          ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ],
                          );
                        })
                      else
                        ...flatItems.map((item) {
                          return Padding(
                            padding: EdgeInsets.symmetric(vertical: 5.h),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Text(item.title ?? "",
                                        style: TextStyle(
                                            fontSize: 14.sp,
                                            fontWeight: FontWeight.bold,
                                            color: AppTheme.primaryColor)),
                                  ),
                                  Text("${item.qty}",
                                      style: TextStyle(
                                          fontSize: 14.sp,
                                          fontWeight: FontWeight.bold,
                                          color: AppTheme.primaryColor)),
                                ]),
                          );
                        }),

                      SizedBox(height: 15.h),
                      const Divider(),
                      SizedBox(height: 10.h),

                      // Price Breakdown (Styled Match)
                      // Dynamic Sub-Total Row
                      _buildSummaryRow(
                          provider.subTotalHeading,
                          CommonMethods.setPriceFormatString(provider.subTotal),
                          isBlueValue: true),

                      // Shipping (Native Parity)
                      if (context.read<DashboardProvider>().profileResponse?.results?.firstOrNull?.showShippingSegment == "Yes")
                        _buildSummaryRow(
                            "Shipping :",
                            CommonMethods.setPriceFormat((double.tryParse(provider.shippingCharge) ?? 0) + (double.tryParse(provider.locationDeliveryCharge) ?? 0)),
                            isBlueValue: true),

                      // Extra Charges if any
                      if (context.read<DashboardProvider>().profileResponse?.results?.firstOrNull?.showShippingSegment != "Yes") ...[
                        if ((double.tryParse(provider.shippingCharge) ?? 0) > 0)
                          _buildSummaryRow(
                              "Shipping :",
                              CommonMethods.setPriceFormatString(
                                  provider.shippingCharge),
                              isBlueValue: true),

                        if ((double.tryParse(provider.supplierCharge) ?? 0) > 0)
                          _buildSummaryRow(
                              "Supplier Charges :",
                              CommonMethods.setPriceFormatString(
                                  provider.supplierCharge),
                              isBlueValue: true),
                      ],

                      // GST (Only if > 0)
                      if ((double.tryParse(provider.taxTotal) ?? 0) > 0)
                        _buildSummaryRow(
                            "GST :",
                            CommonMethods.setPriceFormatString(
                                provider.taxTotal),
                            isBlueValue: true),

                      // Levy (Only if > 0)
                      if ((double.tryParse(provider.levy) ?? 0) > 0)
                        _buildSummaryRow(
                            "Levy :",
                            CommonMethods.setPriceFormatString(provider.levy),
                            isBlueValue: true),

                      // WET (Only if > 0)
                      if ((double.tryParse(provider.wet) ?? 0) > 0)
                        _buildSummaryRow(
                            "WET :",
                            CommonMethods.setPriceFormatString(provider.wet),
                            isBlueValue: true),

                      if ((double.tryParse(provider.couponDiscount) ?? 0) > 0)
                        _buildSummaryRow("Coupon (${provider.couponName})",
                            "-${CommonMethods.setPriceFormatString(provider.couponDiscount)}",
                            isDiscount: true),

                      SizedBox(height: 10.h),

                      _buildSummaryRow(
                          provider.totalHeading,
                          CommonMethods.setPriceFormatString(
                              provider.totalAmount),
                          isBlueValue: true),
                    ],
                  ),
                ),

                if (provider.orderNotesController.text.trim().isNotEmpty) ...[
                  SizedBox(height: 15.h),
                  _buildCard(
                    context,
                    title: "Addition Information",
                    onEdit: () => provider.goToStep(2), // Go to Payment where it's edited
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Order Notes",
                            style:
                                TextStyle(fontSize: 12.sp, color: Colors.grey)),
                        SizedBox(height: 2.h),
                        Text(
                          provider.orderNotesController.text.trim(),
                          style: TextStyle(
                              fontSize: 13.sp,
                              color: AppTheme.primaryColor,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ],

                SizedBox(height: 15.h),

                // 2. Address Details Card
                _buildCard(
                  context,
                  title: "Address Details",
                  onEdit: () => provider.goToStep(1), // Go to Address
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Delivery Address",
                          style:
                              TextStyle(fontSize: 12.sp, color: Colors.grey)),
                      SizedBox(height: 2.h),
                      Text(
                        _formatAddress(
                          provider.shipFirstNameController.text,
                          provider.shipLastNameController.text,
                          provider.shipStreetController.text,
                          provider.shipCityController.text,
                          provider.shipStateController.text,
                          provider.shipPostCodeController.text,
                        ),
                        style: TextStyle(
                            fontSize: 13.sp,
                            color: AppTheme.primaryColor,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10.h),
                      Text("Billing Address",
                          style:
                              TextStyle(fontSize: 12.sp, color: Colors.grey)),
                      SizedBox(height: 2.h),
                      Text(
                        _formatAddress(
                          provider.billFirstNameController
                              .text, // Assuming Billing is same or populated
                          provider.billLastNameController.text,
                          provider.billStreetController.text,
                          provider.billCityController.text,
                          provider.billStateController.text,
                          provider.billPostCodeController.text,
                        ),
                        style: TextStyle(
                            fontSize: 13.sp,
                            color: AppTheme.primaryColor,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 15.h),

                // 3. Payment Details Card
                _buildCard(
                  context,
                  title: "Payment Details",
                  onEdit: () => provider.goToStep(2), // Go to Payment
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Payment Method",
                          style:
                              TextStyle(fontSize: 12.sp, color: Colors.grey)),
                      SizedBox(height: 2.h),
                      Text(
                        provider.paymentMethod.isNotEmpty
                            ? provider.paymentMethod
                            : "Not Selected",
                        style: TextStyle(
                            fontSize: 13.sp,
                            color: AppTheme.primaryColor,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),

                SizedBox(
                    height:
                        30.h), // Extra space for scrolling above sticky footer
              ],
            ),
          ),
        ),

        // Sticky Bottom Footer
        Container(
          padding: EdgeInsets.all(16.w),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withValues(alpha: 0.3),
                blurRadius: 10,
                offset: Offset(0, -3),
              ),
            ],
          ),
          child: Row(
            children: [
              // Back Button (Matching other steps)
              Expanded(
                flex: 3,
                child: SizedBox(
                   height: 40.h,
                   child: ElevatedButton(
                    onPressed: () {
                      provider.previousStep();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF5A623), // Orange/Yellow
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.zero,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5.r),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.arrow_back_ios,
                            color: Colors.white, size: 14.sp),
                        Text(" Back",
                            style: TextStyle(
                                fontSize: 13.sp, // Reduced slightly to be safe
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ),

              // Dynamic Step Indicator
              Expanded(
                flex: 4,
                child: Center(
                  child: Text("${provider.currentStep + 1}/${provider.totalSteps}",
                      style: TextStyle(
                          color: AppTheme.primaryColor,
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold)),
                ),
              ),

              // Submit Order Button
              Expanded(
                flex: 4,
                child: SizedBox(
                  height: 40.h,
                  child: ElevatedButton(
                    onPressed: provider.isLoading
                        ? null
                        : () {
                            provider.placeOrder(context);
                          },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.tealColor, // Dynamic Theme Color
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.zero,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5.r),
                      ),
                      elevation: 2,
                    ),
                    child: provider.isLoading
                        ? SizedBox(
                            width: 20.w,
                            height: 20.w,
                            child: CustomLoaderWidget(size: 20.w),
                          )
                        : FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                              provider.paymentMethod == "Cash on Delivery"
                                  ? "Submit Order"
                                  : "Proceed To Pay",
                              style: TextStyle(
                                  fontSize: 13.sp, fontWeight: FontWeight.bold),
                            ),
                        ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _formatAddress(String fName, String lName, String street, String city,
      String state, String zip) {
    List<String> parts = [];
    String name = "$fName $lName".trim();
    if (name.isNotEmpty) parts.add(name);
    // Logic matches Android: "rajat mehra, malviya nagar, jaipur, jaipur rajasthan 302017"
    if (street.isNotEmpty) parts.add(street);
    if (city.isNotEmpty) parts.add(city);
    String stateZip = "$state $zip".trim();
    if (stateZip.isNotEmpty) parts.add(stateZip);

    if (parts.isEmpty) return "Not provided";
    return parts.join(", ");
  }

  Widget _buildCard(BuildContext context,
      {required String title,
      required VoidCallback onEdit,
      required Widget child}) {
    return Container(
      padding: EdgeInsets.all(15.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5.r),
        boxShadow: [
          BoxShadow(
              color: Colors.grey.withValues(alpha: 0.2),
              blurRadius: 4,
              spreadRadius: 1),
        ],
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryColor, // Blue
                ),
              ),
              InkWell(
                onTap: onEdit,
                child: Icon(Icons.edit_outlined,
                    color: AppTheme.primaryColor, size: 20.sp),
              ),
            ],
          ),
          SizedBox(height: 10.h),
          const Divider(),
          SizedBox(height: 10.h),
          child,
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value,
      {bool isBlueValue = false, bool isDiscount = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
                fontSize: 14.sp,
                color: Colors.grey.shade700,
                fontWeight: FontWeight.w600),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.bold,
              color: isDiscount
                  ? Colors.red
                  : (isBlueValue ? AppTheme.primaryColor : Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}
