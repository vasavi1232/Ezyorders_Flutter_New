import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:logger/logger.dart';
import '../../core/errors/failures.dart';

import '../../core/di/service_locator.dart';
import '../../core/services/session_service.dart';

class ApiClient {
  final http.Client client;
  final Logger logger;

  ApiClient({http.Client? client, Logger? logger})
      : client = client ?? http.Client(),
        logger = logger ?? Logger();

  Future<dynamic> post(String uri,
      {Map<String, dynamic>? body, Map<String, String>? headers}) async {
    try {
      // Clean up body to match Retrofit behavior (omit nulls and empty strings for optional params)
      // Exception: selected_products must be sent even if empty for Banners/Promotions filters to work.
      if (body != null) {
        body.removeWhere((key, value) => value == null);
      }

      logger.d('POST Request: $uri\nBody: $body');

      final response = await client.post(
        Uri.parse(uri),
        body:
            body, // http package handles map -> form-url-encoded automatically for map body
        headers: headers,
      );

      logger
          .d('Response Status: ${response.statusCode}\nBody: ${response.body}');

      return _processResponse(response);
    } on SocketException {
      throw const ServerFailure('No Internet connection');
    } catch (e) {
      throw ServerFailure(e.toString());
    }
  }

  Future<dynamic> get(String uri, {Map<String, String>? headers}) async {
    try {
      logger.d('GET Request: $uri');

      final response = await client.get(
        Uri.parse(uri),
        headers: headers,
      );

      logger
          .d('Response Status: ${response.statusCode}\nBody: ${response.body}');

      return _processResponse(response);
    } on SocketException {
      throw const ServerFailure('No Internet connection');
    } catch (e) {
      throw ServerFailure(e.toString());
    }
  }

  dynamic _processResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (response.body.isEmpty) return {};
      try {
        final decoded = json.decode(response.body);

        // Check for universal session expiration in the body
        if (decoded is Map) {
          final status = decoded['status'];
          final message = decoded['message'];
          // Only trigger global logout for 401 or explicit messages.
          // 403 is too broad for global logout as it can be used for generic data errors.
          if (status == 401 ||
              message == "Unauthorized" ||
              message == "Session Expired") {
            getIt<SessionService>().notifySessionExpired();
          }
        }

        return decoded;
      } catch (e) {
        return response.body; // Return string if not JSON
      }
    } else {
      // Check for 401 status code (Global Unauthorized)
      if (response.statusCode == 401) {
        getIt<SessionService>().notifySessionExpired();
      }

      throw ServerFailure('Error ${response.statusCode}: ${response.body}');
    }
  }
}
