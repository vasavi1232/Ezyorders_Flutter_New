class CommonMethods {
  static String productsBack = "";
  static String supplierIDs = "";
  static String categoryIDs = "";
  static String groupIDs = "";
  static String subGroupIDs = "";
  static String subSubGroupIDs = "";
  static String selecetedProducts = "";
  static String selectFirstTime = "";
  static String tagIDs = "";
  static String sortIDs = "";
  static String firstSuppliers = "";
  static String firstGroupids = "";
  static String firstSubGroupids = "";
  static String firstCatIds = "";
  static String firstSelProds = "";
  static String firstTags = "";
  static String filterSelected = "All Products";

  // Shared pagination and state
  static String cartCount = "0";
  static int supplierCount = 0;
  static String suppliers = "";

  // Dynamic Price Formatting (Synced with Native Android CommonMethods.kt)
  static String priceCode = "AUD";
  static int decimalDigits = 2;

  static String setPriceFormat(double? price) {
    if (price == null) return "$priceCode 0.${'0' * decimalDigits}";
    return "$priceCode ${price.toStringAsFixed(decimalDigits)}";
  }

  static String setPriceFormatString(String? priceString) {
    if (priceString == null || priceString.isEmpty)
      return "$priceCode 0.${'0' * decimalDigits}";
    double? price = double.tryParse(priceString);
    if (price == null) return "$priceCode 0.${'0' * decimalDigits}";
    return "$priceCode ${price.toStringAsFixed(decimalDigits)}";
  }

  static void resetProductFilters() {
    productsBack = "";
    supplierIDs = "";
    categoryIDs = "";
    groupIDs = "";
    subGroupIDs = "";
    subSubGroupIDs = "";
    selecetedProducts = "";
    selectFirstTime = "";
    tagIDs = "";
    sortIDs = "";
    firstSuppliers = "";
    firstGroupids = "";
    firstSubGroupids = "";
    firstCatIds = "";
    firstSelProds = "";
    firstTags = "";
    filterSelected = "All Products";
  }

  static String findDiscount(String? price, String? promoPrice) {
    if (price == null || promoPrice == null) return "0";

    // Strip everything except digits and dots
    String cleanPrice = price.replaceAll(RegExp(r'[^0-9.]'), '');
    String cleanPromo = promoPrice.replaceAll(RegExp(r'[^0-9.]'), '');

    final priceVal = double.tryParse(cleanPrice) ?? 0.0;
    final promoVal = double.tryParse(cleanPromo) ?? 0.0;

    if (priceVal <= 0 || promoVal <= 0 || promoVal >= priceVal) return "0";
    final discount = ((priceVal - promoVal) / priceVal) * 100;
    
    // Round to 3 decimal places using CEILING logic
    double rounded = (discount * 1000).ceilToDouble() / 1000;
    return rounded.toStringAsFixed(3);
  }

  static String checkNullempty(String? value) {
    if (value == null || value.isEmpty || value == "null") {
      return "";
    }
    return value;
  }

  static String decodeHtmlEntities(String? text, {bool stripTags = false}) {
    if (text == null) return "";

    // First decode basic named entities
    String decoded = text
        .replaceAll("&amp;", "&")
        .replaceAll("&AMP;", "&")
        .replaceAll("&lt;", "<")
        .replaceAll("&LT;", "<")
        .replaceAll("&gt;", ">")
        .replaceAll("&GT;", ">")
        .replaceAll("&quot;", "\"")
        .replaceAll("&QUOT;", "\"")
        .replaceAll("&apos;", "'")
        .replaceAll("&APOS;", "'");

    // Then decode numeric entities (e.g., &#39; or &#039; or &#160;)
    decoded = decoded.replaceAllMapped(RegExp(r'&#(\d+);'), (match) {
      final intCode = int.tryParse(match.group(1)!);
      if (intCode != null) {
        return String.fromCharCode(intCode);
      }
      return match.group(0)!; // fallback to original if parsing fails
    });

    if (stripTags) {
      decoded = decoded.replaceAll(RegExp(r'<[^>]*>'), '');
    }

    return decoded.trim();
  }

  static String calculateDiscount(String? original, String? promo) {
    if (original == null || promo == null) return "0";
    double o = double.tryParse(original) ?? 0;
    double p = double.tryParse(promo) ?? 0;
    if (o <= 0) return "0";
    
    double discountPrice = p / o;
    double totalDisPrice = 100 - (discountPrice * 100);
    // Round to 3 decimal places using CEILING logic
    double rounded = (totalDisPrice * 1000).ceilToDouble() / 1000;
    
    // Format to 3 decimal places
    String result = rounded.toStringAsFixed(3);
    
    // Remove trailing zeros ONLY if it's strictly requested or if it's .000
    // But user asked for 3 decimals, so we keep them for precision matching prices.
    // result = result.replaceAll(RegExp(r'0*$'), '');
    // result = result.replaceAll(RegExp(r'\.$'), '');
    return result;
  }

  static double safeSize(double value, {double defaultValue = 0.0, double? min}) {
    if (value.isNaN || value.isInfinite) {
      return defaultValue;
    }
    if (min != null && value < min) {
      return min;
    }
    return value;
  }

  static String getTaxLabel(bool isExcl, {required String levy, required String wet, required String gst}) {
    List<String> labels = [];
    double l = double.tryParse(levy) ?? 0;
    double w = double.tryParse(wet) ?? 0;
    double g = double.tryParse(gst) ?? 0;

    String prefix = isExcl ? "Ex. " : "Inc. ";

    if (l > 0) labels.add("${prefix}Levy");
    if (w > 0) labels.add("${prefix}Wet");
    if (g > 0 || labels.isEmpty) labels.add("${prefix}GST");

    return "${labels.join(", ")} :";
  }

  static String formatApiLabel(String? label) {
    if (label == null || label.isEmpty || label == "null") return "";

    // Replace <br/> with newline if present
    String formatted =
        label.replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n');

    // Basic HTML tag stripping (if any other tags exist)
    formatted = formatted.replaceAll(RegExp(r'<[^>]*>'), '');

    // Trim and ensure colon at the end
    formatted = formatted.trim();
    if (formatted.isNotEmpty && !formatted.endsWith(':')) {
      formatted = "$formatted :";
    }

    return formatted;
  }
}
