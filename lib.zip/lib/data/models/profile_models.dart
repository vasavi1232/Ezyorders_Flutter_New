class ProfileResponse {
  int? status;
  String? message;
  int? resultsCount;
  List<ProfileResult>? results;

  ProfileResponse({this.status, this.message, this.resultsCount, this.results});

  factory ProfileResponse.fromJson(Map<String, dynamic> json) {
    return ProfileResponse(
      status: json['status'],
      message: json['message'],
      resultsCount: json['results_count'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => ProfileResult.fromJson(i))
              .toList()
          : null,
    );
  }
}

class ProfileResult {
  String? customerId;
  String? firstName;
  String? lastName;
  String? email;
  String? phone;
  String? subTotalHeading;
  String? totalHeading;
  String? allowToReviewOrderBeforeSubmitting;
  String? unreadNotificationsCount;
  String? showMarqueText;
  String? marqueText;
  String? marqueTextColor;
  String? marqueTextBackgroundColor;
  String? marqueTextFormat;
  int? marqueTextSize;
  String? allowCustomerToCancelOrder; // Added for Order Parity
  String? allowCustomersToReplicateOrders; // Added for Order Parity
  String? allowCustomerToReorderSameProducts; // Added for Order Parity
  String? showSupplierStatus; // Added for Order Details Parity
  String? showLevy;
  String? showWet;
  String? supplierLogosPosition; // Added for Dashboard layout
  String? suppliers;
  String? suppliersCount;
  String? priceDisplayType;
  String? priceDisplayTypeDecimals;
  String? showSoldAs;
  String? bestSellers;
  String? productsAdvertisements;
  String? hotSelling;
  String? supplierLogos;
  String? popularCategories;
  String? flashDeals;
  String? newArrivals;
  String? recentlyAdded;
  String? customerLoginLogo;
  List<dynamic>? wishlist;
  List<AddressItem>? addressesList;

  // Add other profile fields as needed, but these are critical for Checkout

  ProfileResult({
    this.customerId,
    this.firstName,
    this.lastName,
    this.email,
    this.phone,
    this.subTotalHeading,
    this.totalHeading,
    this.allowToReviewOrderBeforeSubmitting,
    this.unreadNotificationsCount,
    this.showMarqueText,
    this.marqueText,
    this.marqueTextColor,
    this.marqueTextBackgroundColor,
    this.marqueTextFormat,
    this.marqueTextSize,
    this.allowCustomerToCancelOrder,
    this.allowCustomersToReplicateOrders,
    this.allowCustomerToReorderSameProducts,
    this.showSupplierStatus,
    this.showLevy,
    this.showWet,
    this.supplierLogosPosition,
    this.suppliers,
    this.suppliersCount,
    this.priceDisplayType,
    this.priceDisplayTypeDecimals,
    this.showSoldAs,
    this.bestSellers,
    this.productsAdvertisements,
    this.hotSelling,
    this.supplierLogos,
    this.popularCategories,
    this.flashDeals,
    this.newArrivals,
    this.recentlyAdded,
    this.customerLoginLogo,
    this.wishlist,
    this.addressesList,
  });

  factory ProfileResult.fromJson(Map<String, dynamic> json) {
    return ProfileResult(
      customerId: json['customer_id']?.toString(),
      firstName: json['first_name']?.toString(),
      lastName: json['last_name']?.toString(),
      email: json['email']?.toString(),
      phone: json['phone']?.toString(),
      subTotalHeading: json['sub_total_heading']?.toString(),
      totalHeading: json['total_heading']?.toString(),
      allowToReviewOrderBeforeSubmitting:
          json['allow_to_review_order_before_submmitting']?.toString(),
      unreadNotificationsCount: json['unread_notifications_count']?.toString(),
      showMarqueText: json['show_marque_text']?.toString(),
      marqueText: json['marque_text']?.toString(),
      marqueTextColor: json['marque_text_color']?.toString(),
      marqueTextBackgroundColor:
          json['marque_text_background_color']?.toString(),
      marqueTextFormat: json['marque_text_format']?.toString(),
      marqueTextSize: json['marque_text_size'] is int
          ? json['marque_text_size']
          : int.tryParse(json['marque_text_size']?.toString() ?? ''),
      allowCustomerToCancelOrder: json['allow_customer_to_cancel_order']?.toString(),
      allowCustomersToReplicateOrders: json['allow_customers_to_replicate_orders']?.toString(),
      allowCustomerToReorderSameProducts: json['allow_customer_to_reorder_same_products']?.toString(),
      showSupplierStatus: json['show_supplier_status']?.toString(),
      showLevy: json['show_levy']?.toString(),
      showWet: json['show_wet']?.toString(),
      supplierLogosPosition: json['supplier_logos_position']?.toString(),
      suppliers: json['suppliers']?.toString(),
      suppliersCount: json['suppliers_count']?.toString(),
      priceDisplayType: json['price_display_type']?.toString(),
      priceDisplayTypeDecimals: json['price_display_type_decimals']?.toString(),
      showSoldAs: json['show_sold_as']?.toString(),
      bestSellers: json['best_sellers']?.toString(),
      productsAdvertisements: json['products_advertisements']?.toString(),
      hotSelling: json['hot_selling']?.toString(),
      supplierLogos: json['supplier_logos']?.toString(),
      popularCategories: json['popular_categories']?.toString(),
      flashDeals: json['flash_deals']?.toString(),
      newArrivals: json['new_arrivals']?.toString(),
      recentlyAdded: json['recently_added']?.toString(),
      customerLoginLogo: json['customer_login_logo']?.toString(),
      wishlist: json['wishlist'] as List?,
      addressesList: json['addresses_list'] != null
          ? (json['addresses_list'] as List)
              .map((i) => AddressItem.fromJson(i))
              .toList()
          : null,
    );
  }
}

class AddressItem {
  String? addressId;
  String? firstName;
  String? lastName;
  String? email;
  String? phone;
  String? street;
  String? street2;
  String? suburb;
  String? state;
  String? postcode;
  String? country;
  String? defaultAddress;
  String? deliveryLocationId;
  String? deliveryLocationCharge;
  String? isChecked; // Local UI state

  AddressItem({
    this.addressId,
    this.firstName,
    this.lastName,
    this.email,
    this.phone,
    this.street,
    this.street2,
    this.suburb,
    this.state,
    this.postcode,
    this.country,
    this.defaultAddress,
    this.deliveryLocationId,
    this.deliveryLocationCharge,
    this.isChecked = "No",
  });

  factory AddressItem.fromJson(Map<String, dynamic> json) {
    return AddressItem(
      addressId: json['address_id']?.toString(),
      firstName: json['first_name']?.toString(),
      lastName: json['last_name']?.toString(),
      email: json['email']?.toString(),
      phone: json['phone']?.toString(),
      street: json['street']?.toString(),
      street2: json['street2']?.toString(),
      suburb: json['suburb']?.toString(),
      state: json['state']?.toString(),
      postcode: json['postcode']?.toString(),
      country: json['country']?.toString(),
      defaultAddress: json['default_address']?.toString(),
      deliveryLocationId: json['delivery_location_id']?.toString(),
      deliveryLocationCharge: json['delivery_location_charge']?.toString() ??
          json['location_delivery_charge']?.toString(),
      isChecked: "No",
    );
  }
}
