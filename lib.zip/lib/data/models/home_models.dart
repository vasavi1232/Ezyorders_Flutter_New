class BannersResponse {
  int? status;
  String? message;
  List<BannerItem?>? results;

  BannersResponse({this.status, this.message, this.results});

  factory BannersResponse.fromJson(Map<String, dynamic> json) {
    return BannersResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? BannerItem.fromJson(i) : null)
              .toList()
          : null,
    );
  }
}

class BannerItem {
  String? bannerId; // banner_id
  String? name; // name (was banner_title)
  String? image; // image (was banner_image)
  String? topCaption; // top_caption
  String? bottomCaption; // bottom_caption
  String? linkImageTo; // link_image_to
  String? divisionId; // division_id
  String? groupId; // group_id
  String? productId; // product_id
  String? sortOrder; // sort_order
  String? externalLink; // external_link
  String? products; // products

  BannerItem({
    this.bannerId,
    this.name,
    this.image,
    this.topCaption,
    this.bottomCaption,
    this.linkImageTo,
    this.divisionId,
    this.groupId,
    this.productId,
    this.sortOrder,
    this.externalLink,
    this.products,
  });

  factory BannerItem.fromJson(Map<String, dynamic> json) {
    return BannerItem(
      bannerId: json['banner_id']?.toString(),
      name: json['name']?.toString(),
      image: json['image']?.toString(),
      topCaption: json['top_caption']?.toString(),
      bottomCaption: json['bottom_caption']?.toString(),
      linkImageTo: json['link_image_to']?.toString(),
      divisionId: json['division_id']?.toString(),
      groupId: json['group_id']?.toString(),
      productId: json['product_id']?.toString(),
      sortOrder: json['sort_order']?.toString(),
      externalLink: json['external_link']?.toString(),
      products: json['products']?.toString(),
    );
  }
}

class FooterBannersResponse {
  int? status;
  String? message;
  List<BannerItem?>? results;

  FooterBannersResponse({this.status, this.message, this.results});
  factory FooterBannersResponse.fromJson(Map<String, dynamic> json) {
    return FooterBannersResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? BannerItem.fromJson(i) : null)
              .toList()
          : null,
    );
  }
}

class ProfileResponse {
  int? status;
  String? message;
  List<ProfileResult?>? results;
  int? resultsCount;
  String? cartQuantity;
  String? suppliersCount;
  String? suppliers;

  ProfileResponse({
    this.status,
    this.message,
    this.results,
    this.resultsCount,
    this.cartQuantity,
    this.suppliersCount,
    this.suppliers,
  });

  factory ProfileResponse.fromJson(Map<String, dynamic> json) {
    return ProfileResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? ProfileResult.fromJson(i) : null)
              .toList()
          : null,
      resultsCount: json['results_count'],
      cartQuantity: json['cart_quantity']?.toString(),
      suppliersCount: json['suppliers_count']?.toString(),
      suppliers: json['suppliers']?.toString(),
    );
  }
}

class ProfileResult {
  String? customerId;
  String? firstName;
  String? lastName;
  String? email;
  String? phone;
  String? mobile;
  String? street;
  String? street2;
  String? suburb;
  String? state;
  String? postcode;
  String? image;
  String? unreadNotificationsCount;
  String? wishlistPageHeading;
  String? status;
  String? showPortalIn;
  String? accNum;
  String? allowScanToOrder;
  String? priceDisplayTypeDecimals;
  String? priceDisplayType;
  String? supplierLogosPosition;
  String? maximumNumberOfSuppliersProductsForFreeShipping;
  String? showMarqueText;
  String? marqueText;
  String? marqueTextColor;
  String? marqueTextSize;
  String? marqueTextBackgroundColor;
  String? marqueTextFormat;
  String? bestSellers;
  String? productsAdvertisements;
  String? hotSelling;
  String? supplierLogos;
  String? popularCategories;
  String? flashDeals;
  String? newArrivals;
  String? recentlyAdded;
  String? customerMessageForAdditionalSuppliersCharge;
  String? showShippingSegment;
  String? showSoldAs;
  String? companyMobile;
  String? companyEmail;
  String? companyStreet;
  String? companySuburb;
  String? companyState;
  String? companyPostcode;
  List<ProductItem?>? wishlist; // Added
  int? wishlistCount; // Added
  String? allowToReviewOrderBeforeSubmitting; // Added
  String? customerLoginLogo; // Added
  String? subTotalHeading; // Added
  String? totalHeading; // Added
  String? allowCustomerToCancelOrder; // Added for Order Parity
  String? allowCustomersToReplicateOrders; // Added for Order Parity
  String? allowCustomerToReorderSameProducts; // Added for Order Parity
  String? showSupplierStatus; // Added for Order Details Parity
  String? showLevy; // Added for Dynamic Labeling
  String? showWet; // Added for Dynamic Labeling
  String? allowCustomersToAddWishlist; // Added for Wishlist Visibility
  String? replicateOrderConfirmationText;
  String? reorderConfirmationText;
  String? restrictOnMinOrderAmountNotReached;
  String? minimumOrderAmount;
  String? minOrderNotificationText;
  String? restrictOnMaxOrderAmountReached;
  String? maxOrderAmount;
  String? maxOrderNotificationText;
  String? allowNewUserSignUp; // Added for Sign Up Parity

  ProfileResult({
    this.customerId,
    this.firstName,
    this.lastName,
    this.email,
    this.phone,
    this.mobile,
    this.street,
    this.street2,
    this.suburb,
    this.state,
    this.postcode,
    this.image,
    this.unreadNotificationsCount,
    this.wishlistPageHeading,
    this.status,
    this.showPortalIn,
    this.accNum,
    this.allowScanToOrder,
    this.priceDisplayTypeDecimals,
    this.priceDisplayType,
    this.supplierLogosPosition,
    this.maximumNumberOfSuppliersProductsForFreeShipping,
    this.showMarqueText,
    this.marqueText,
    this.marqueTextColor,
    this.marqueTextSize,
    this.marqueTextBackgroundColor,
    this.marqueTextFormat,
    this.bestSellers,
    this.productsAdvertisements,
    this.hotSelling,
    this.supplierLogos,
    this.popularCategories,
    this.flashDeals,
    this.newArrivals,
    this.recentlyAdded,
    this.customerMessageForAdditionalSuppliersCharge,
    this.showShippingSegment,
    this.showSoldAs,
    this.companyMobile,
    this.companyEmail,
    this.companyStreet,
    this.companySuburb,
    this.companyState,
    this.companyPostcode,
    this.wishlist, // Added
    this.wishlistCount, // Added
    this.allowToReviewOrderBeforeSubmitting, // Added
    this.customerLoginLogo, // Added
    this.subTotalHeading, // Added
    this.totalHeading, // Added
    this.allowCustomerToCancelOrder,
    this.allowCustomersToReplicateOrders,
    this.allowCustomerToReorderSameProducts,
    this.showSupplierStatus,
    this.showLevy,
    this.showWet,
    this.allowCustomersToAddWishlist,
    this.replicateOrderConfirmationText,
    this.reorderConfirmationText,
    this.restrictOnMinOrderAmountNotReached,
    this.minimumOrderAmount,
    this.minOrderNotificationText,
    this.restrictOnMaxOrderAmountReached,
    this.maxOrderAmount,
    this.maxOrderNotificationText,
    this.allowNewUserSignUp,
  });

  factory ProfileResult.fromJson(Map<String, dynamic> json) {
    return ProfileResult(
      customerId: json['customer_id']?.toString(),
      firstName: json['first_name']?.toString(),
      lastName: json['last_name']?.toString(),
      email: json['email']?.toString(),
      phone: json['phone']?.toString(),
      mobile: json['mobile']?.toString(),
      street: json['street']?.toString(),
      street2: json['street2']?.toString(),
      suburb: json['suburb']?.toString(),
      state: json['state']?.toString(),
      postcode: json['postcode']?.toString(),
      image: json['image']?.toString(),
      unreadNotificationsCount: json['unread_notifications_count']?.toString(),
      wishlistPageHeading: json['wishlist_page_heading']?.toString(),
      status: json['status']?.toString(),
      showPortalIn: json['show_portal_in']?.toString(),
      accNum: json['acc_num']?.toString(),
      allowScanToOrder: json['allow_scan_to_order']?.toString(),
      priceDisplayTypeDecimals: json['price_display_type_decimals']?.toString(),
      priceDisplayType: json['price_display_type']?.toString(),
      supplierLogosPosition: json['supplier_logos_position']?.toString(),
      maximumNumberOfSuppliersProductsForFreeShipping:
          json['maximum_number_of_suppliers_products_for_free_shipping']
              ?.toString(),
      showMarqueText: json['show_marque_text']?.toString(),
      marqueText: json['marque_text']?.toString(),
      marqueTextColor: json['marque_text_color']?.toString(),
      marqueTextSize: json['marque_text_size']?.toString(),
      marqueTextBackgroundColor:
          json['marque_text_background_color']?.toString(),
      marqueTextFormat: json['marque_text_format']?.toString(),
      bestSellers: json['best_sellers']?.toString(),
      productsAdvertisements: json['products_advertisements']?.toString(),
      hotSelling: json['hot_selling']?.toString(),
      supplierLogos: json['supplier_logos']?.toString(),
      popularCategories: json['popular_categories']?.toString(),
      flashDeals: json['flash_deals']?.toString(),
      newArrivals: json['new_arrivals']?.toString(),
      recentlyAdded: json['recently_added']?.toString(),
      customerMessageForAdditionalSuppliersCharge:
          json['customer_message_for_additional_suppliers_charge']?.toString(),
      showShippingSegment: json['show_shipping_segment']?.toString(),
      showSoldAs: json['show_sold_as']?.toString(),
      companyMobile: json['company_mobile']?.toString(),
      companyEmail: json['company_email']?.toString(),
      companyStreet: json['company_street']?.toString(),
      companySuburb: json['company_suburb']?.toString(),
      companyState: json['company_state']?.toString(),
      companyPostcode: json['company_postcode']?.toString(),
      wishlist: json['wishlist'] != null
          ? (json['wishlist'] as List)
              .map((i) => i != null ? ProductItem.fromJson(i) : null)
              .toList()
          : null,
      wishlistCount: json['wishlist_count'],
      allowToReviewOrderBeforeSubmitting:
          json['allow_to_review_order_before_submmitting']?.toString(),
      customerLoginLogo: json['customer_login_logo']?.toString(),
      subTotalHeading: json['sub_total_heading']?.toString(),
      totalHeading: json['total_heading']?.toString(),
      allowCustomerToCancelOrder: json['allow_customer_to_cancel_order']?.toString(),
      allowCustomersToReplicateOrders: json['allow_customers_to_replicate_orders']?.toString(),
      allowCustomerToReorderSameProducts: json['allow_customer_to_reorder_same_products']?.toString(),
      showSupplierStatus: json['show_supplier_status']?.toString(),
      showLevy: json['show_levy']?.toString(),
      showWet: json['show_wet']?.toString(),
      allowCustomersToAddWishlist: json['allow_customers_to_add_wishlist']?.toString(),
      replicateOrderConfirmationText: json['replicate_order_confirmation_text']?.toString(),
      reorderConfirmationText: json['reorder_confirmation_text']?.toString(),
      restrictOnMinOrderAmountNotReached: json['restrict_on_min_order_amount_not_reached']?.toString(),
      minimumOrderAmount: json['minimum_order_amount']?.toString(),
      minOrderNotificationText: json['min_order_notification_text']?.toString(),
      restrictOnMaxOrderAmountReached: json['restrict_on_max_order_amount_reached']?.toString(),
      maxOrderAmount: json['max_order_amount']?.toString(),
      maxOrderNotificationText: json['max_order_notification_text']?.toString(),
      allowNewUserSignUp: json['allow_new_user_sign_up']?.toString(),
    );
  }
}

class HomeBlocksResponse {
  int? status;
  String? message;
  List<HomeBlockItem?>? results;

  HomeBlocksResponse({this.status, this.message, this.results});
  factory HomeBlocksResponse.fromJson(Map<String, dynamic> json) {
    return HomeBlocksResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? HomeBlockItem.fromJson(i) : null)
              .toList()
          : null,
    );
  }
}

class HomeBlockItem {
  String? id;
  String? companyId;
  String? name;
  String? image;
  String? description;
  String? sortOrder;
  String? status;

  HomeBlockItem(
      {this.id,
      this.companyId,
      this.name,
      this.image,
      this.description,
      this.sortOrder,
      this.status});

  factory HomeBlockItem.fromJson(Map<String, dynamic> json) {
    return HomeBlockItem(
      id: json['id']?.toString(),
      companyId: json['company_id']?.toString(),
      name: json['name']?.toString(),
      image: json['image']?.toString(),
      description: json['description']?.toString(),
      sortOrder: json['sort_order']?.toString(),
      status: json['status']?.toString(),
    );
  }
}

class ProductItem {
  String? productId;
  String? name; // Added for ProductDetailItem compatibility
  String? title;
  String? description;
  String? shortDescription; // Added for ProductDetailItem compatibility
  String? image;
  String? brandName;
  String? brandId;
  String? price;
  String? promotionPrice;
  String? stockUnlimited;
  String? qtyStatus;
  String? availableStockQty;
  String? minimumOrderQty;
  String? soldAs;
  String? isFavourite;
  String? productAvailable; // Changed to String to handle 1/"1"
  String? supplierAvailable; // Changed to String
  String? notAvailableDaysMessage;
  String? addedToCart;
  String? addedQty;
  String? addedSubTotal;
  String? orderedAs;
  String? qtyPerOuter; // Added for unit logic
  String? apiData;
  String? divisionId;
  String? groupId;
  String? sku;
  String? gst; // Added for ProductDetailItem compatibility
  String? gstPercentage;
  String? fromDate;
  String? toDate;
  String? hasPromotion; // Added field
  String?
      label; // Added for promotional badges (Best Seller, New Arrival, etc.)
  String? discountPercentage; // Added for ProductDetailItem compatibility
  String? discountId; // Added for ProductDetailItem compatibility
  String? discountName; // Added for ProductDetailItem compatibility
  String? wishlistId; // Added for Wishlist
  String? wishlistCategoryId; // Added for Wishlist
  List<ProductItem>? products; // Added for Promotions Banner nested products

  ProductItem({
    this.productId,
    this.name,
    this.title,
    this.description,
    this.shortDescription,
    this.image,
    this.brandName,
    this.brandId,
    this.price,
    this.promotionPrice,
    this.stockUnlimited,
    this.qtyStatus,
    this.availableStockQty,
    this.minimumOrderQty,
    this.soldAs,
    this.isFavourite,
    this.productAvailable,
    this.supplierAvailable,
    this.notAvailableDaysMessage,
    this.addedToCart,
    this.addedQty,
    this.addedSubTotal,
    this.orderedAs,
    this.qtyPerOuter,
    this.apiData,
    this.divisionId,
    this.groupId,
    this.sku,
    this.gst,
    this.gstPercentage,
    this.fromDate,
    this.toDate,
    this.hasPromotion,
    this.label,
    this.discountPercentage,
    this.discountId,
    this.discountName,
    this.wishlistId,
    this.wishlistCategoryId,
    this.products,
  });

  factory ProductItem.fromJson(Map<String, dynamic> json) {
    return ProductItem(
      productId: json['product_id']?.toString(),
      name: json['name']?.toString(),
      title: json['title']?.toString(),
      description: json['description']?.toString(),
      shortDescription: json['short_description']?.toString(),
      image: json['image']?.toString(),
      brandName: json['brand_name']?.toString(),
      brandId: json['brand_id']?.toString(),
      price: json['price']?.toString(),
      promotionPrice: json['promotion_price']?.toString(),
      stockUnlimited: json['stock_unlimited']?.toString(),
      qtyStatus: json['qty_status']?.toString(),
      availableStockQty: json['available_stock_qty']?.toString(),
      minimumOrderQty: json['minimum_order_qty']?.toString(),
      soldAs: json['sold_as']?.toString(),
      isFavourite: json['is_favourite']?.toString(),
      productAvailable: json['product_available']?.toString(),
      supplierAvailable: json['supplier_available']?.toString(),
      notAvailableDaysMessage: json['not_available_days_message']?.toString(),
      addedToCart: json['added_to_cart']?.toString(),
      addedQty: json['added_qty']?.toString(),
      addedSubTotal: json['added_sub_total']?.toString(),
      orderedAs: json['ordered_as']?.toString(),
      qtyPerOuter: json['qty_per_outer']?.toString(),
      apiData: json['api_data']?.toString(),
      divisionId: json['division_id']?.toString(),
      groupId: json['group_id']?.toString(),
      sku: json['sku']?.toString(),
      gst: json['gst']?.toString(),
      gstPercentage: json['gst_percentage']?.toString(),
      fromDate: json['from_date']?.toString().isNotEmpty == true
          ? json['from_date'].toString()
          : json['promotion_from_date_time']?.toString(),
      toDate: json['to_date']?.toString().isNotEmpty == true
          ? json['to_date'].toString()
          : json['promotion_to_date_time']?.toString(),
      hasPromotion: json['has_promotion']?.toString(),
      label: json['label']?.toString(),
      discountPercentage: json['discount_percentage']?.toString(),
      discountId: json['discount_id']?.toString(),
      discountName: json['discount_name']?.toString(),
      wishlistId: json['wishlist_id']?.toString(),
      wishlistCategoryId: json['wishlist_category_id']?.toString(),
      products: json['products'] != null
          ? (json['products'] as List)
              .map((i) => i != null ? ProductItem.fromJson(i) : null)
              .whereType<ProductItem>()
              .toList()
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'product_id': productId,
      'name': name,
      'title': title,
      'description': description,
      'short_description': shortDescription,
      'image': image,
      'brand_name': brandName,
      'brand_id': brandId,
      'price': price,
      'promotion_price': promotionPrice,
      'stock_unlimited': stockUnlimited,
      'qty_status': qtyStatus,
      'available_stock_qty': availableStockQty,
      'minimum_order_qty': minimumOrderQty,
      'sold_as': soldAs,
      'is_favourite': isFavourite,
      'product_available': productAvailable,
      'supplier_available': supplierAvailable,
      'not_available_days_message': notAvailableDaysMessage,
      'added_to_cart': addedToCart,
      'added_qty': addedQty,
      'added_sub_total': addedSubTotal,
      'ordered_as': orderedAs,
      'qty_per_outer': qtyPerOuter,
      'api_data': apiData,
      'division_id': divisionId,
      'group_id': groupId,
      'sku': sku,
      'gst': gst,
      'gst_percentage': gstPercentage,
      'from_date': fromDate,
      'to_date': toDate,
      'has_promotion': hasPromotion,
      'label': label,
      'discount_percentage': discountPercentage,
      'discount_id': discountId,
      'discount_name': discountName,
      'wishlist_id': wishlistId,
      'wishlist_category_id': wishlistCategoryId,
      'products': products?.map((e) => e.toJson()).toList(),
    };
  }
}

class DashboardProductsResponse {
  int? status;
  String? message;
  List<ProductItem?>? results;

  DashboardProductsResponse({this.status, this.message, this.results});
  factory DashboardProductsResponse.fromJson(Map<String, dynamic> json) {
    return DashboardProductsResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? ProductItem.fromJson(i) : null)
              .toList()
          : null,
    );
  }
}

class PromotionsResponse {
  int? status;
  String? message;
  List<ProductItem?>? results;

  PromotionsResponse({this.status, this.message, this.results});
  factory PromotionsResponse.fromJson(Map<String, dynamic> json) {
    return PromotionsResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? ProductItem.fromJson(i) : null)
              .toList()
          : null,
    );
  }
}

class FlashDealsResponse {
  int? status;
  String? message;
  List<ProductItem?>? results;

  FlashDealsResponse({this.status, this.message, this.results});
  factory FlashDealsResponse.fromJson(Map<String, dynamic> json) {
    return FlashDealsResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? ProductItem.fromJson(i) : null)
              .toList()
          : null,
    );
  }
}

class PopularCategoryItem {
  String? divisionId;
  String? groupLevel1;
  String? image;
  String? popularCategory;
  String? categoryProductsCount; // Added

  PopularCategoryItem(
      {this.divisionId,
      this.groupLevel1,
      this.image,
      this.popularCategory,
      this.categoryProductsCount});

  factory PopularCategoryItem.fromJson(Map<String, dynamic> json) {
    return PopularCategoryItem(
      divisionId: json['division_id']?.toString(),
      groupLevel1: json['group_level_1']?.toString(),
      image: json['image']?.toString(),
      popularCategory: json['popular_category']?.toString(),
      categoryProductsCount: json['category_products_count']?.toString(),
    );
  }
}

class PopularCategoriesResponse {
  int? status;
  String? message;
  List<PopularCategoryItem?>? results;

  PopularCategoriesResponse({this.status, this.message, this.results});
  factory PopularCategoriesResponse.fromJson(Map<String, dynamic> json) {
    return PopularCategoriesResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? PopularCategoryItem.fromJson(i) : null)
              .toList()
          : null,
    );
  }
}

class BrandItem {
  String? brandId;
  String? brandName;
  String? image;
  String? brandNumber;
  String? topBrand;
  String? majorBrand;
  String? status;
  String? companyId;

  BrandItem(
      {this.brandId,
      this.brandName,
      this.image,
      this.brandNumber,
      this.topBrand,
      this.majorBrand,
      this.status,
      this.companyId});

  factory BrandItem.fromJson(Map<String, dynamic> json) {
    return BrandItem(
      brandId: json['brand_id']?.toString(),
      brandName: json['brand_name']?.toString(),
      image: json['image']?.toString(),
      brandNumber: json['brand_number']?.toString(),
      topBrand: json['top_brand']?.toString(),
      majorBrand: json['major_brand']?.toString(),
      status: json['status']?.toString(),
      companyId: json['company_id']?.toString(),
    );
  }
}

class SupplierLogosResponse {
  int? status;
  String? message;
  List<BrandItem?>? results;

  SupplierLogosResponse({this.status, this.message, this.results});
  factory SupplierLogosResponse.fromJson(Map<String, dynamic> json) {
    return SupplierLogosResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? BrandItem.fromJson(i) : null)
              .toList()
          : null,
    );
  }
}

class PopularAdvertosementsResponse {
  int? status;
  String? message;
  List<SupplierItem?>? results;

  PopularAdvertosementsResponse({this.status, this.message, this.results});
  factory PopularAdvertosementsResponse.fromJson(Map<String, dynamic> json) {
    return PopularAdvertosementsResponse(
      status: json['status'],
      message: json['message'],
      results: json['results'] != null
          ? (json['results'] as List)
              .map((i) => i != null ? SupplierItem.fromJson(i) : null)
              .toList()
          : null,
    );
  }
}

class SupplierItem {
  String? image;
  String? externalLink;
  String? brandid;

  SupplierItem({this.image, this.externalLink, this.brandid});

  factory SupplierItem.fromJson(Map<String, dynamic> json) {
    return SupplierItem(
      image: json['image']?.toString(),
      externalLink: json['external_link']?.toString(),
      brandid: json['brand_id']?.toString(),
    );
  }
}

extension ProductItemCopyWith on ProductItem {
  ProductItem copyWith({
    String? addedToCart,
    String? addedQty,
    String? addedSubTotal,
    String? orderedAs,
    String? isFavourite,
  }) {
    return ProductItem(
      productId: productId,
      name: name,
      title: title,
      description: description,
      shortDescription: shortDescription,
      image: image,
      brandName: brandName,
      brandId: brandId,
      price: price,
      promotionPrice: promotionPrice,
      stockUnlimited: stockUnlimited,
      qtyStatus: qtyStatus,
      availableStockQty: availableStockQty,
      minimumOrderQty: minimumOrderQty,
      soldAs: soldAs,
      isFavourite: isFavourite ?? this.isFavourite,
      productAvailable: productAvailable,
      supplierAvailable: supplierAvailable,
      notAvailableDaysMessage: notAvailableDaysMessage,
      addedToCart: addedToCart ?? this.addedToCart,
      addedQty: addedQty ?? this.addedQty,
      addedSubTotal: addedSubTotal ?? this.addedSubTotal,
      orderedAs: orderedAs ?? this.orderedAs,
      qtyPerOuter: qtyPerOuter,
      apiData: apiData,
      divisionId: divisionId,
      groupId: groupId,
      sku: sku,
      gst: gst,
      gstPercentage: gstPercentage,
      fromDate: fromDate,
      toDate: toDate,
      hasPromotion: hasPromotion,
      label: label,
      discountPercentage: discountPercentage,
      discountId: discountId,
      discountName: discountName,
      wishlistId: wishlistId,
      wishlistCategoryId: wishlistCategoryId,
    );
  }
}
