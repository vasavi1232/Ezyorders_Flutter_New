import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../providers/checkout_provider.dart';
import '../../../../core/constants/app_theme.dart';
import '../../../../core/utils/common_methods.dart';
import '../../../providers/dashboard_provider.dart';
import '../../../widgets/custom_loader_widget.dart';
import '../../cart/widgets/delivery_location_dialog.dart';
import 'cart_item_refined_widget.dart';
import 'clear_cart_dialog.dart';
import 'package:go_router/go_router.dart';
import '../../../../config/routes/app_routes.dart';
import '../../../../data/models/delivery_location_response.dart';
import 'package:fluttertoast/fluttertoast.dart';

class StepCartWidget extends StatefulWidget {
  const StepCartWidget({super.key});

  @override
  State<StepCartWidget> createState() => _StepCartWidgetState();
}

class _StepCartWidgetState extends State<StepCartWidget> {
  bool _isExpanded = true;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CheckoutProvider>();
    final cartResult = provider.cartResult;

    if (provider.isLoading) {
      return Center(child: CustomLoaderWidget(size: 40.w));
    }

    if (cartResult == null || (cartResult.brands?.isEmpty ?? true)) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_cart_outlined, size: 60.sp, color: Colors.grey),
            SizedBox(height: 10.h),
            Text("No Products added to Cart.",
                style: TextStyle(
                    fontSize: 16.sp,
                    color:
                        Colors.grey)), // Exact text from dialog_emptycart.xml
            SizedBox(height: 20.h),
            // Back to Home Button
            ElevatedButton(
              onPressed: () {
                context.read<DashboardProvider>().refreshDashboard();
                Navigator.pop(context); // Or navigate to dashboard
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.tealColor,
                foregroundColor: Colors.white,
                minimumSize: Size(150.w, 40.h),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5.r)),
              ),
              child: Text("Back to Home"),
            )
          ],
        ),
      );
    }

    return Column(
      children: [
        // Header (Delivery Location) - Simplified for now as per XML snippet inspection
        // fragment_shoppingcart.xml has a layout at top for delivery location?
        // Actually it wasn't explicitly in the snippet I viewed, but I'll add a placeholder if provider has it.
        // Provider has `updateDeliveryLocationAPI`, so there must be a selector.
        // Assuming it's a dropdown or text.

        Builder(builder: (context) {
          final profileResult = context.read<DashboardProvider>().profileResponse?.results?.firstOrNull;
          final subtotalVal = double.tryParse(provider.subTotal) ?? 0.0;
          String? warningText;

          if (profileResult?.restrictOnMinOrderAmountNotReached == "Yes") {
            final minAmt = double.tryParse(profileResult?.minimumOrderAmount ?? "0") ?? 0.0;
            if (minAmt - subtotalVal > 0.0) {
              warningText = CommonMethods.decodeHtmlEntities(profileResult?.minOrderNotificationText, stripTags: true);
            } else if (profileResult?.restrictOnMaxOrderAmountReached == "Yes") {
               final maxAmt = double.tryParse(profileResult?.maxOrderAmount ?? "0") ?? 0.0;
               if (subtotalVal - maxAmt > 0.0) {
                   warningText = CommonMethods.decodeHtmlEntities(profileResult?.maxOrderNotificationText, stripTags: true);
               }
            }
          } else if (profileResult?.restrictOnMaxOrderAmountReached == "Yes") {
             final maxAmt = double.tryParse(profileResult?.maxOrderAmount ?? "0") ?? 0.0;
             if (subtotalVal - maxAmt > 0.0) {
                 warningText = CommonMethods.decodeHtmlEntities(profileResult?.maxOrderNotificationText, stripTags: true);
             }
          }

          if (warningText == null || warningText.isEmpty) return const SizedBox.shrink();

          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
            child: Text(
              warningText,
              style: TextStyle(
                color: AppTheme.redColor,
                fontSize: 12.sp,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          );
        }),

        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.only(bottom: 10.h),
            itemCount: cartResult.brands?.length ?? 0,
            itemBuilder: (context, index) {
              final brand = cartResult.brands![index];
              if (brand == null) return SizedBox.shrink();

              // For each brand, verify how it's displayed. XML shows item_cart has a header logic in adapter.
              // Here we stick to listing products.
              return Column(
                children: brand.products?.map((product) {
                      if (product == null) return SizedBox.shrink();
                      int pIndex = brand.products!.indexOf(product);

                      return CartItemRefinedWidget(
                        item: product,
                        showHeader:
                            pIndex == 0, // Show header for first item of brand
                        brandName: brand.brandName ?? "",
                        brandId: brand.brandId ?? "",
                        onUpdateQty: (newQty) async {
                          // Fix: Ensure we send valid price on update
                          String priceOne = product.salePrice ?? "0";
                          if ((double.tryParse(priceOne) ?? 0) <= 0) {
                            priceOne = product.normalPrice ?? "0";
                          }
                          await provider.updateCartItem(
                              product.productId!,
                              newQty,
                              brand.brandId!,
                              priceOne,
                              product.orderedAs ?? "");
                          if (context.mounted) {
                            context
                                .read<DashboardProvider>()
                                .setCartCount(CommonMethods.cartCount);
                          }
                        },
                        onDelete: () async {
                          await provider.deleteCartItem(
                              product.productId!, brand.brandId!);
                          if (context.mounted) {
                            context
                                .read<DashboardProvider>()
                                .setCartCount(CommonMethods.cartCount);
                          }
                        },
                      );
                    }).toList() ??
                    [],
              );
            },
          ),
        ),

        // Removed warning from bottom

        // Bottom Section (Price Details & Actions)
        Container(

          decoration: BoxDecoration(
            color: Colors.white,
            // Match Native Shadow: distinct shadow lifting the footer
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withValues(alpha: 0.3),
                blurRadius: 10,
                spreadRadius: 2,
                offset: Offset(0, -3),
              )
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [


              // Expandable Price Details header
              InkWell(
                onTap: () {
                  setState(() {
                    _isExpanded = !_isExpanded;
                  });
                },
                child: Padding(
                  padding:
                      EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        (context.read<DashboardProvider>().profileResponse?.results?.firstOrNull?.showShippingSegment == "Yes" && provider.deliveryLocations.isNotEmpty)
                            ? "Shipping"
                            : "Cart Total",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16.sp,
                            color: AppTheme.primaryColor),
                      ),
                      Container(
                        padding: EdgeInsets.all(4.w),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xFF27AE60), // Green from screenshot
                        ),
                        child: Icon(
                          _isExpanded
                              ? Icons.keyboard_arrow_up
                              : Icons.keyboard_arrow_down,
                          color: Colors.white,
                          size: 18.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (_isExpanded)
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 15.w, vertical: 5.h),
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Delivery Location Selection (Native Parity)
                      if (context.read<DashboardProvider>().profileResponse?.results?.firstOrNull?.showShippingSegment == "Yes" && provider.deliveryLocations.isNotEmpty)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Choose Your Delivery Location",
                              style: TextStyle(
                                fontSize: 13.sp,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(height: 5.h),
                            Text(
                              "Delivery Location",
                              style: TextStyle(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(height: 5.h),
                            InkWell(
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (context) => DeliveryLocationDialog(
                                    deliveryLocations: provider.deliveryLocations,
                                    selectedDeliveryLocationId: provider.selectedDeliveryLocationId,
                                    onLocationSelected: (locationId, charge) {
                                      provider.updateDeliveryLocation(locationId, charge);
                                    },
                                  ),
                                );
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 12.h),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey.shade400),
                                  borderRadius: BorderRadius.circular(4.r),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Text(
                                        provider.selectedDeliveryLocationId == null
                                            ? "Select Delivery Location"
                                            : () {
                                                final bool exists = provider.deliveryLocations.any((loc) => loc.deliveryLocationId == provider.selectedDeliveryLocationId);
                                                if (!exists) return "Select Delivery Location";
                                                final selectedLoc = provider.deliveryLocations.firstWhere(
                                                    (loc) => loc.deliveryLocationId == provider.selectedDeliveryLocationId);
                                                String displayText = selectedLoc.locationName ?? "Select Delivery Location";
                                                if (selectedLoc.subLocationName != null && selectedLoc.subLocationName!.isNotEmpty) {
                                                  displayText += " - ${selectedLoc.subLocationName}";
                                                }
                                                return displayText;
                                              }(),
                                        style: TextStyle(
                                          fontSize: 14.sp,
                                          color: provider.selectedDeliveryLocationId == null
                                              ? Colors.grey.shade600
                                              : AppTheme.primaryColor,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    const Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryColor),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(height: 5.h),
                            if (provider.selectedDeliveryLocationId != null)
                              Builder(builder: (context) {
                                final selectedLoc = provider.deliveryLocations.firstWhere(
                                    (loc) => loc.deliveryLocationId == provider.selectedDeliveryLocationId,
                                    orElse: () => DeliveryLocationResult());
                                String displayText = selectedLoc.locationName ?? "";
                                if (selectedLoc.subLocationName != null && selectedLoc.subLocationName!.isNotEmpty) {
                                  displayText += " - ${selectedLoc.subLocationName}";
                                }
                                return RichText(
                                  text: TextSpan(
                                    text: "Selected Delivery Location : ",
                                    style: TextStyle(fontSize: 13.sp, color: AppTheme.primaryColor),
                                    children: [
                                      TextSpan(
                                        text: displayText,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }),
                            SizedBox(height: 10.h),
                          ],
                        ),

                      // Sub-Total Section
                      _buildSummaryRow(
                          provider.subTotalHeading,
                          CommonMethods.setPriceFormatString(provider.subTotal),
                          isBlueValue: true),



                      // Levy (Only if > 0)
                      if ((double.tryParse(provider.levy) ?? 0) > 0)
                        _buildSummaryRow(
                            "Levy :",
                            CommonMethods.setPriceFormatString(provider.levy),
                            isBlueValue: true),

                      // WET (Only if > 0)
                      if ((double.tryParse(provider.wet) ?? 0) > 0)
                        _buildSummaryRow(
                            "WET :",
                            CommonMethods.setPriceFormatString(provider.wet),
                            isBlueValue: true),

                      // Shipping (Native Parity)
                      if (context.read<DashboardProvider>().profileResponse?.results?.firstOrNull?.showShippingSegment == "Yes")
                        _buildSummaryRow("Shipping :",
                            CommonMethods.setPriceFormat((double.tryParse(provider.shippingCharge) ?? 0) + (double.tryParse(provider.locationDeliveryCharge) ?? 0)),
                            isBlueValue: true),

                      // Extra Charges if any
                      if (context.read<DashboardProvider>().profileResponse?.results?.firstOrNull?.showShippingSegment != "Yes")
                        if ((double.tryParse(provider.shippingCharge) ?? 0) > 0)
                          _buildSummaryRow(
                              "Shipping Charges",
                              CommonMethods.setPriceFormatString(
                                  provider.shippingCharge),
                              isBlueValue: true),

                      // GST (Only if > 0)
                      if ((double.tryParse(provider.taxTotal) ?? 0) > 0)
                        _buildSummaryRow(
                            "GST :",
                            CommonMethods.setPriceFormatString(
                                provider.taxTotal),
                            isBlueValue: true),

                      if ((double.tryParse(provider.supplierCharge) ?? 0) > 0)
                        _buildSummaryRow(
                            "Supplier Charges",
                            CommonMethods.setPriceFormatString(
                                provider.supplierCharge),
                            isBlueValue: true),
                      if ((double.tryParse(provider.couponDiscount) ?? 0) > 0)
                        _buildSummaryRow("Coupon (${provider.couponName})",
                            "-${CommonMethods.setPriceFormatString(provider.couponDiscount)}",
                            isDiscount: true),

                      SizedBox(height: 10.h),

                      SizedBox(height: 10.h),
                      _buildSummaryRow(
                          provider.totalHeading,
                          CommonMethods.setPriceFormatString(
                              provider.totalAmount),
                          isBlueValue: true),
                      SizedBox(height: 5.h),
                    ],
                  ),
                ),

              // Action Buttons (pd_next_back_layout)
              Padding(
                padding: EdgeInsets.all(15.w),
                child: Row(
                  children: [
                    // Clear Cart (Red CustomButton)
                    Expanded(
                      flex: 4,
                      child: SizedBox(
                        height: 40.h,
                        child: ElevatedButton(
                          onPressed: () {
                            _showClearCartDialog(context, provider);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.redColor, // Darker Red
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5.r)),
                          ),
                          child: Text("Clear Cart",
                              style: TextStyle(
                                  color: Colors.white, fontSize: 14.sp)),
                        ),
                      ),
                    ),

                    // Dynamic Step Indicator
                    Expanded(
                      flex: 3,
                      child: Center(
                        child: Text("${provider.currentStep + 1}/${provider.totalSteps}",
                            style: TextStyle(
                                color: AppTheme.primaryColor,
                                fontSize: 15.sp,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),

                    // Next (Orange)
                    Expanded(
                      flex: 4,
                      child: InkWell(
                        onTap: () {
                          // 1. Check delivery location (showShippingSegment == "Yes")
                          bool requiresDelivery = context.read<DashboardProvider>().profileResponse?.results?.firstOrNull?.showShippingSegment == "Yes";
                          
                          if (requiresDelivery) {
                            String? currentId = provider.selectedDeliveryLocationId?.trim();
                            bool isInvalid = currentId == null || 
                                             currentId.isEmpty || 
                                             currentId == "0" || 
                                             currentId.toLowerCase() == "null";
                            if (isInvalid) {
                              Fluttertoast.showToast(msg: "Please choose your delivery location");
                              return;
                            }
                          }

                          // 2. Min/Max order amount validation (matches Android ShoppingCartFragment)
                          final profileResult = context.read<DashboardProvider>().profileResponse?.results?.firstOrNull;
                          final subtotalVal = double.tryParse(provider.subTotal) ?? 0.0;

                          if (profileResult?.restrictOnMinOrderAmountNotReached == "Yes") {
                            final minAmt = double.tryParse(profileResult?.minimumOrderAmount ?? "0") ?? 0.0;
                            if (minAmt - subtotalVal > 0.0) {
                              _showOrderAmountDialog(context, CommonMethods.decodeHtmlEntities(profileResult?.minOrderNotificationText ?? "Minimum order amount not reached.", stripTags: true));
                              return;
                            } else if (profileResult?.restrictOnMaxOrderAmountReached == "Yes") {
                                final maxAmt = double.tryParse(profileResult?.maxOrderAmount ?? "0") ?? 0.0;
                                if (subtotalVal - maxAmt > 0.0) {
                                  _showOrderAmountDialog(context, CommonMethods.decodeHtmlEntities(profileResult?.maxOrderNotificationText ?? "Maximum order amount exceeded.", stripTags: true));
                                  return;
                                }
                            }
                          } else if (profileResult?.restrictOnMaxOrderAmountReached == "Yes") {
                             final maxAmt = double.tryParse(profileResult?.maxOrderAmount ?? "0") ?? 0.0;
                             if (subtotalVal - maxAmt > 0.0) {
                               _showOrderAmountDialog(context, CommonMethods.decodeHtmlEntities(profileResult?.maxOrderNotificationText ?? "Maximum order amount exceeded.", stripTags: true));
                               return;
                             }
                          }

                          provider.nextStep();
                          if (provider.errorMessage.isNotEmpty) {
                            Fluttertoast.showToast(msg: provider.errorMessage);
                          }
                        },
                        child: Container(
                          height: 40.h,
                          decoration: BoxDecoration(
                            color: AppTheme.primaryColor, // Orange/Yellow
                            borderRadius: BorderRadius.circular(5.r),
                          ),
                          alignment: Alignment.center,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("Next",
                                  style: TextStyle(
                                      fontSize: 15.sp,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white)),
                              SizedBox(width: 5.w),
                              Icon(Icons.arrow_forward_ios,
                                  color: Colors.white, size: 14.sp),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSummaryRow(String label, String value,
      {bool isDiscount = false, bool isBlueValue = false}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 13.sp,
                  color: Colors.black,
                  fontWeight: FontWeight.w600)),
          Text(value,
              style: TextStyle(
                  fontSize: 14.sp,
                  color: isDiscount
                      ? AppTheme.redColor
                      : (isBlueValue
                          ? AppTheme.primaryColor
                          : AppTheme.darkBlue),
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  void _showClearCartDialog(BuildContext context, CheckoutProvider provider) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => ClearCartDialog(
        onClose: () => Navigator.pop(dialogContext),
        onClear: () async {
          // 1. Close dialog FIRST
          Navigator.pop(dialogContext);

          // 2. Perform Clear Action
          await provider.clearCart();

          // 3. Force Update Dashboard Provider & Navigate
          if (context.mounted) {
            final dashboardProvider = context.read<DashboardProvider>();

            // Update global cart count to 0
            dashboardProvider.setCartCount("0");

            // Reset to Home Tab
            dashboardProvider.setIndex(0);

            // Trigger Full Refresh
            dashboardProvider.init();

            // Navigate to Dashboard (Home) to refresh state
            context.go(AppRoutes.dashboard);
          }
        },
      ),
    );
  }

  void _showOrderAmountDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.r)),
        child: Padding(
          padding: EdgeInsets.all(20.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Order Amount",
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(dialogContext),
                    child: Icon(Icons.close, color: Colors.grey, size: 20.sp),
                  ),
                ],
              ),
              SizedBox(height: 12.h),
              Text(
                message,
                style: TextStyle(fontSize: 14.sp, color: Colors.black87),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 16.h),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5.r)),
                  ),
                  child: Text("OK",
                      style: TextStyle(color: Colors.white, fontSize: 14.sp)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
