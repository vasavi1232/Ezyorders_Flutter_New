import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/constants/app_theme.dart';
import '../../../../core/constants/url_api_key.dart';
import '../../../../core/network/image_cache_manager.dart';
import '../../../../core/utils/common_methods.dart';
import '../../../../data/models/home_models.dart';
import '../../../providers/dashboard_provider.dart';
import 'package:provider/provider.dart';
import '../product_details_screen.dart';
import '../../dashboard/widgets/not_available_dialog.dart';

class ProductGridItem extends StatefulWidget {
  final ProductItem item;
  final VoidCallback? onTap;
  final Function(int qty)? onAddToCart;
  final VoidCallback? onFavorite;
  final bool showSoldAs;

  const ProductGridItem({
    super.key,
    required this.item,
    this.onTap,
    this.onAddToCart,
    this.onFavorite,
    this.showSoldAs = true,
  });

  @override
  State<ProductGridItem> createState() => _ProductGridItemState();
}

class _ProductGridItemState extends State<ProductGridItem> {
  @override
  Widget build(BuildContext context) {
    final bool isOutOfStock = widget.item.qtyStatus == "Out Of Stock";
    final bool canAddToCart = widget.item.supplierAvailable == "1" &&
        widget.item.productAvailable == "1" &&
        !isOutOfStock;
    final bool hasPromotion = widget.item.hasPromotion == "Yes" &&
        widget.item.promotionPrice != null &&
        double.tryParse(widget.item.promotionPrice ?? "0")! > 0;

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
      ),
      child: Card(
        elevation: 1, // Reduced elevation
        color: Colors.white,
        margin: EdgeInsets.all(0), // Removed margin to be tight
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: InkWell(
          onTap: widget.onTap ??
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        ProductDetailsScreen(productId: widget.item.productId!),
                  ),
                );
              },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Sold As
              Consumer<DashboardProvider>(
                builder: (context, dashboard, child) {
                  final bool showSoldAsProfile =
                      dashboard.profileResponse?.results?[0]?.showSoldAs ==
                          "Yes";
                  if (!widget.showSoldAs || !showSoldAsProfile) {
                    return const SizedBox.shrink();
                  }

                  if (widget.item.soldAs != null &&
                      widget.item.soldAs!.isNotEmpty) {
                    return Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(vertical: 5.h),
                      decoration: const BoxDecoration(
                        color: AppTheme.tealColor,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        widget.item.soldAs == "Each"
                            ? "Each"
                            : "${widget.item.soldAs} (${widget.item.qtyPerOuter} Units)",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w800),
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),

              SizedBox(height:4.h),

              // Image & Tag
              Stack(
                children: [
                  Container(
                    height: 105.h,
                    width: double.infinity,
                    alignment: Alignment.center,
                    child: CachedNetworkImage(
                      imageUrl: _getImageUrl(widget.item.image),
                      fit: BoxFit.contain,
                      cacheManager: ImageCacheManager(),
                      placeholder: (context, url) =>
                          Container(color: Colors.grey[100]),
                      errorWidget: (context, url, error) =>
                          const Icon(Icons.broken_image),
                    ),
                  ),
                  if (widget.item.label != null &&
                      widget.item.label!.isNotEmpty)
                    Positioned(
                      top: 5.h,
                      left: 5.w,
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 5.w, vertical: 3.h),
                        decoration: BoxDecoration(
                          color: AppTheme.redColor,
                          borderRadius: BorderRadius.circular(3.r),
                        ),
                        child: Text(
                          widget.item.label!,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 9.sp,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                ],
              ),

              Padding(
                padding: EdgeInsets.all(8.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Vendor
                    SizedBox(height: 5.h),
                    Text(
                      CommonMethods.decodeHtmlEntities(widget.item.brandName ?? ""),
                      style: TextStyle(
                          color: AppTheme.darkerGrayColor,
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w800),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),

                    // Title
                    SizedBox(height: 2.h),
                    Text(
                      CommonMethods.decodeHtmlEntities(widget.item.title ?? ""),
                      style: TextStyle(
                          color: AppTheme.textColor,
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w800),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),

                    // MOQ
                    if (widget.item.minimumOrderQty != null &&
                        widget.item.minimumOrderQty != "0" &&
                        widget.item.minimumOrderQty != "1")
                      Padding(
                        padding: EdgeInsets.only(top: 5.h),
                        child: Text(
                          "MOQ : ${widget.item.minimumOrderQty}",
                          style: TextStyle(
                              color: AppTheme.redColor,
                              fontSize: 11.sp,
                              fontWeight: FontWeight.bold),
                        ),
                      ),

                    // Price Section
                    SizedBox(height: 5.h),
                    if (!hasPromotion)
                      Text(
                        _formatPrice(widget.item.price),
                        style: TextStyle(
                            color: AppTheme.darkerGrayColor,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w800),
                      )
                    else
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                _formatPrice(
                                    widget.item.price), // Original Price (Was)
                                style: TextStyle(
                                    color: AppTheme.darkerGrayColor,
                                    fontSize: 12.sp,
                                    decoration: TextDecoration.lineThrough,
                                  fontWeight: FontWeight.w800
                                ),
                              ),
                              SizedBox(width: 5.w),
                              Text(
                                _formatPrice(widget
                                    .item.promotionPrice), // Promo Price (Now)
                                style: TextStyle(
                                    color: AppTheme.primaryColor,
                                    fontSize: 12.sp,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2.h),
                            padding: EdgeInsets.symmetric(
                                horizontal: 5.w, vertical: 2.h),
                            decoration: BoxDecoration(
                              color: AppTheme.redColor,
                              borderRadius: BorderRadius.circular(2.r),
                            ),
                            child: Text(
                              "-${CommonMethods.calculateDiscount(widget.item.price, widget.item.promotionPrice)}%",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 8.sp,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),

              const Spacer(),

              // Actions
              Padding(
                padding: EdgeInsets.all(5.w),
                child: Column(
                  children: [
                    // Quantity Control
                    /*if (canAddToCart)
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey[300]!),
                          borderRadius: BorderRadius.circular(AppTheme.inputRadius.r),
                        ),
                        margin: EdgeInsets.only(bottom: 5.h), // Spacing below quantity
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              onTap: _decrementQty,
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 3.h),
                                child: Icon(Icons.remove, size: 16.sp, color: Colors.grey[600]),
                              ),
                            ),
                            Text(
                               _quantity.toString(),
                               style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.bold),
                            ),
                            InkWell(
                              onTap: _incrementQty,
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 3.h),
                                child: Icon(Icons.add, size: 16.sp, color: Colors.grey[600]),
                              ),
                            ),
                          ],
                        ),
                      ),*/

                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: isOutOfStock
                                ? null
                                : (canAddToCart && widget.onAddToCart != null
                                    ? () => widget.onAddToCart!(1)
                                    : () {
                                        final supplierName = widget.item.supplierAvailable == "0"
                                            ? (widget.item.brandName ?? widget.item.title ?? "")
                                            : (widget.item.name ?? widget.item.title ?? "");
                                        
                                        showDialog(
                                          context: context,
                                          builder: (context) => NotAvailableDialog(
                                            supplierName: supplierName,
                                            description: widget.item.notAvailableDaysMessage ?? "",
                                          ),
                                        );
                                      }),
                            child: Container(
                              height: 35.h,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: canAddToCart
                                    ? AppTheme.tealColor
                                    : AppTheme.redColor,
                                borderRadius: BorderRadius.circular(
                                    AppTheme.productButtonRadius.r),
                              ),
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  isOutOfStock
                                      ? "Out Of Stock"
                                      : (widget.item.addedToCart == "Yes"
                                          ? "Update Cart [${widget.item.addedQty ?? '1'}]"
                                          : "Add To Cart"),
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 12.sp,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Consumer<DashboardProvider>(
                          builder: (context, dashboard, _) {
                            final allowWishlist = dashboard.profileResponse
                                    ?.results?.firstOrNull
                                    ?.allowCustomersToAddWishlist ==
                                "Yes";
                            if (!allowWishlist) return const SizedBox.shrink();
                            return Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SizedBox(width: 20.w),
                                InkWell(
                                  onTap: widget.onFavorite,
                                  child: Image.asset(
                                    widget.item.isFavourite == "Yes"
                                        ? "assets/images/favadded.png"
                                        : "assets/images/fav_new.png",
                                    width: 30.h,
                                    height: 30.h,
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 5.h),
            ],
          ),
        ),
      ),
    );
  }

  String _getImageUrl(String? path) {
    if (path == null || path.isEmpty) return "";
    if (path.startsWith("http")) return path;
    return "${UrlApiKey.mainUrl}$path";
  }

  String _formatPrice(String? price) {
    return CommonMethods.setPriceFormatString(price);
  }
}
