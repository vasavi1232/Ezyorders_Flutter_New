import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../../core/constants/app_theme.dart';
import '../../../../core/constants/url_api_key.dart';
import '../../../../core/utils/common_methods.dart';
import '../../../../data/models/cart_models.dart';
import '../../../providers/cart_provider.dart';
import '../../../providers/dashboard_provider.dart';
import '../../../widgets/custom_loader_widget.dart';
import 'package:fluttertoast/fluttertoast.dart';

class CartItemWidget extends StatelessWidget {
  final CartProduct item;

  const CartItemWidget({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.r)),
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image
            ClipRRect(
              borderRadius: BorderRadius.circular(8.r),
              child: CachedNetworkImage(
                imageUrl: "${UrlApiKey.mainUrl}${item.image}",
                width: 80.w,
                height: 80.h,
                fit: BoxFit.cover,
                placeholder: (context, url) => Container(
                  color: Colors.grey[200],
                  child: Center(child: CustomLoaderWidget(size: 30.w)),
                ),
                errorWidget: (context, url, error) => const Icon(Icons.error),
              ),
            ),
            SizedBox(width: 10.w),

            // Details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (item.brandName != null && item.brandName!.isNotEmpty)
                    Padding(
                      padding: EdgeInsets.only(bottom: 4.h),
                      child: Text(
                        item.brandName!,
                        style: TextStyle(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryColor,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  Text(
                    CommonMethods.decodeHtmlEntities(item.title),
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 4.h),

                  // Price Section
                  (() {
                    double normal = double.tryParse(item.normalPrice ?? "0") ?? 0;
                    double sale = double.tryParse(item.salePrice ?? "0") ?? 0;
                    
                    // A discount exists if sale price is strictly less than normal price
                    // We check difference > 0.01 to avoid small floating point issues
                    bool hasDiscount = sale > 0 && (normal - sale) > 0.01;

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (hasDiscount) ...[
                          Text(
                            "\$${normal.toStringAsFixed(2)}",
                            style: TextStyle(
                              fontSize: 12.sp,
                              color: AppTheme.darkGrayColor,
                              decoration: TextDecoration.lineThrough,
                            ),
                          ),
                          SizedBox(height: 2.h),
                        ],
                        Row(
                          children: [
                            Text(
                              "\$${hasDiscount ? sale.toStringAsFixed(2) : (sale > 0 ? sale.toStringAsFixed(2) : normal.toStringAsFixed(2))}",
                              style: TextStyle(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.bold,
                                color: AppTheme.darkerGrayColor,
                              ),
                            ),
                            if (hasDiscount) ...[
                              SizedBox(width: 8.w),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 4.w, vertical: 1.h),
                                decoration: BoxDecoration(
                                  color: AppTheme.redColor,
                                  borderRadius: BorderRadius.circular(2.r),
                                ),
                                child: Text(
                                  "-${CommonMethods.calculateDiscount(item.normalPrice, item.salePrice)}%",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11.sp,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    );
                  })(),

                  SizedBox(height: 4.h),
                    Consumer<DashboardProvider>(
                      builder: (context, dashboard, child) {
                        final bool showSoldAs = dashboard.profileResponse?.results?[0]?.showSoldAs == "Yes";
                        if (!showSoldAs) return const SizedBox.shrink();

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 5.h),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: "Ordered As : ",
                                    style: TextStyle(
                                      fontSize: 12.sp,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                  ),
                                  TextSpan(
                                    text: item.orderedAs ?? "",
                                    style: TextStyle(
                                      fontSize: 12.sp,
                                      color: AppTheme.primaryColor,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        );
                      },
                    ),

                  // Qty Controls & Delete
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Qty Control
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey[300]!),
                          borderRadius: BorderRadius.circular(4.r),
                        ),
                        child: Row(
                          children: [
                            InkWell(
                              onTap: () async {
                                int currentQty = item.qty ?? 0;
                                int minQty = int.tryParse(
                                        item.minimumOrderQty ?? "1") ??
                                    1;
                                if (currentQty > minQty) {
                                  await context
                                      .read<CartProvider>()
                                      .updateCartItem(
                                          item, (currentQty - 1).toString());
                                  if (context.mounted) {
                                    context
                                        .read<DashboardProvider>()
                                        .setCartCount(CommonMethods.cartCount);
                                  }
                                }
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8.w, vertical: 4.h),
                                child: Icon(Icons.remove, size: 16.sp),
                              ),
                            ),
                            Container(
                              width: 35.w,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                border: Border.symmetric(
                                  vertical:
                                      BorderSide(color: Colors.grey[300]!),
                                ),
                              ),
                              padding: EdgeInsets.symmetric(vertical: 4.h),
                              child: Text(
                                item.qty?.toString() ?? "0",
                                style: TextStyle(
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                            InkWell(
                              onTap: () async {
                                int currentQty = item.qty ?? 0;
                                
                                // Stock Validation Logic
                                bool isUnlimited = item.stockUnlimited?.toLowerCase() == "yes" || 
                                                  item.qtyStatus?.toLowerCase() == "no";
                                int availableStock = int.tryParse(item.availableStockQty ?? "0") ?? 0;
                                
                                if (!isUnlimited && currentQty >= availableStock) {
                                  Fluttertoast.showToast(
                                    msg: "Only $availableStock items available in stock",
                                    toastLength: Toast.LENGTH_SHORT,
                                    gravity: ToastGravity.BOTTOM,
                                    backgroundColor: Colors.red,
                                    textColor: Colors.white,
                                  );
                                  return;
                                }

                                await context
                                    .read<CartProvider>()
                                    .updateCartItem(
                                        item, (currentQty + 1).toString());
                                if (context.mounted) {
                                  context
                                      .read<DashboardProvider>()
                                      .setCartCount(CommonMethods.cartCount);
                                }
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8.w, vertical: 4.h),
                                child: Icon(Icons.add, size: 16.sp),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Delete
                      InkWell(
                        onTap: () async {
                          await context
                              .read<CartProvider>()
                              .deleteCartItem(item);
                          if (context.mounted) {
                            context
                                .read<DashboardProvider>()
                                .setCartCount(CommonMethods.cartCount);
                          }
                        },
                        child: Icon(Icons.delete,
                            color: AppTheme.redColor, size: 24.sp),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
