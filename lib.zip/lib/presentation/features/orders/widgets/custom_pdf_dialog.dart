import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import '../../../../core/constants/url_api_key.dart';
import '../../../../core/utils/common_methods.dart';

class CustomPdfDialog extends StatefulWidget {
  final String pdfUrl;
  final String orderId;

  const CustomPdfDialog({
    super.key,
    required this.pdfUrl,
    required this.orderId,
  });

  @override
  State<CustomPdfDialog> createState() => _CustomPdfDialogState();
}

class _CustomPdfDialogState extends State<CustomPdfDialog> {
  String? localPath;
  bool isDownloading = true;
  String errorMessage = "";

  @override
  void initState() {
    super.initState();
    _downloadAndSavePdf();
  }

  Future<void> _downloadAndSavePdf() async {
    try {
      String finalUrl = widget.pdfUrl;
      if (!finalUrl.startsWith('http')) {
        finalUrl = UrlApiKey.companyMainUrl +
            (finalUrl.startsWith('/') ? finalUrl.substring(1) : finalUrl);
      }

      // 1. Request Storage Permission (needed for Android 12 and below, or generally saving to public folders)
      // For just viewing, getTemporaryDirectory is fine. Let's save to temp first for viewing.
      final response = await http.get(Uri.parse(finalUrl));
      if (response.statusCode == 200) {
        final bytes = response.bodyBytes;
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/Invoice_${widget.orderId}.pdf');
        await file.writeAsBytes(bytes);

        // Pass finalUrl to FlutterDownloader to handle public background save + notification
        _saveToPublicDownloads(finalUrl);

        if (mounted) {
          debugPrint("PDF Downloaded to: ${file.path}");
          debugPrint("File exists: ${await file.exists()}");
          if (await file.exists()) {
            debugPrint("File size: ${await file.length()} bytes");
          }
          setState(() {
            localPath = file.path;
            isDownloading = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isDownloading = false;
            errorMessage =
                "Failed to load invoice. Server returned ${response.statusCode}";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          isDownloading = false;
          errorMessage = "Error downloading invoice: $e";
        });
      }
    }
  }

  Future<void> _saveToPublicDownloads(String finalUrl) async {
    try {
      if (Platform.isAndroid) {
        var status = await Permission.storage.status;
        if (!status.isGranted) {
          await Permission.storage.request();
        }

        // For Android 13+, photos/audio/video permissions are used instead of storage.
        // However, for Downloads directory, using flutter_downloader often just works if we specify the public Downloads directory.
        Directory? directory;
        if (Platform.isAndroid) {
          directory = Directory('/storage/emulated/0/Download');
          if (!await directory.exists()) {
            directory = await getExternalStorageDirectory();
          }
        } else {
          directory = await getApplicationDocumentsDirectory();
        }

        if (directory != null) {
          await FlutterDownloader.enqueue(
            url: finalUrl,
            savedDir: directory.path,
            fileName: 'Invoice_${widget.orderId}.pdf',
            showNotification:
                true, // show download progress in status bar (for Android)
            openFileFromNotification:
                true, // click on notification to open downloaded file (for Android)
            saveInPublicStorage: true,
          );
        }
      } else if (Platform.isIOS) {
        final dir = await getApplicationDocumentsDirectory();
        await FlutterDownloader.enqueue(
          url: finalUrl,
          savedDir: dir.path,
          fileName: 'Invoice_${widget.orderId}.pdf',
          showNotification: true,
          openFileFromNotification: true,
        );
      }
    } catch (e) {
      debugPrint("Error saving via flutter_downloader: \$e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      elevation: 0,
      insetPadding: EdgeInsets.symmetric(
          horizontal: CommonMethods.safeSize(16.w, min: 1.0), 
          vertical: CommonMethods.safeSize(24.h, min: 1.0)), // Make it almost full screen
      backgroundColor: Colors.transparent,
      child: Container(
        color: Colors.white,
        child: Column(
          children: [
            // Header Bar
            Container(
              color:
                  const Color(0xFFFDB833), // The bright orange from screenshot
              padding: EdgeInsets.symmetric(
                  horizontal: CommonMethods.safeSize(16.w, min: 1.0), 
                  vertical: CommonMethods.safeSize(12.h, min: 1.0)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "View Order Confirmation",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: CommonMethods.safeSize(16.sp, defaultValue: 16),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Icon(Icons.close, 
                        color: Colors.white, 
                        size: CommonMethods.safeSize(24.sp, defaultValue: 24)),
                  ),
                ],
              ),
            ),

            // PDF Body
            Expanded(
              child: isDownloading
                  ? const Center(
                      child:
                          CircularProgressIndicator(color: Color(0xFFFDB833)))
                  : errorMessage.isNotEmpty
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child:
                                Text(errorMessage, textAlign: TextAlign.center),
                          ),
                        )
                      : LayoutBuilder(
                          builder: (context, constraints) {
                            debugPrint("PDF Layout Constraints: ${constraints.maxWidth} x ${constraints.maxHeight}");
                            if (!constraints.maxWidth.isFinite || 
                                !constraints.maxHeight.isFinite ||
                                constraints.maxWidth <= 1 ||
                                constraints.maxHeight <= 1) {
                              debugPrint("INVALID CONSTRAINTS DETECTED");
                              return const Center(
                                  child: Icon(Icons.picture_as_pdf, color: Color(0xFFFDB833), size: 50));
                            }
                            return ColoredBox(
                              color: Colors.white, // Visual isolation
                              child: PDFView(
                                filePath: localPath,
                                enableSwipe: true,
                                swipeHorizontal: false,
                                autoSpacing: Platform.isIOS ? true : false,
                                pageFling: false,
                                fitPolicy: FitPolicy.WIDTH,
                                onRender: (pages) {
                                  debugPrint("PDF Rendered with $pages pages");
                                },
                                onError: (error) {
                                  debugPrint("PDF Error: $error");
                                  setState(() {
                                    errorMessage = error.toString();
                                  });
                                },
                                onPageError: (page, error) {
                                  debugPrint("PDF Page Error: $page - $error");
                                  setState(() {
                                    errorMessage = '$page: ${error.toString()}';
                                  });
                                },
                              ),
                            );
                          },
                        ),
            ),

            // Footer Button
            Padding(
              padding: EdgeInsets.symmetric(
                  vertical: CommonMethods.safeSize(16.h)),
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFDB833), // Orange button
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(CommonMethods.safeSize(4.r, defaultValue: 4))),
                  padding:
                      EdgeInsets.symmetric(
                          horizontal: CommonMethods.safeSize(60.w), 
                          vertical: CommonMethods.safeSize(12.h)),
                ),
                child: Text(
                  "Close",
                  style:
                      TextStyle(
                          fontSize: CommonMethods.safeSize(14.sp, defaultValue: 14), 
                          fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
