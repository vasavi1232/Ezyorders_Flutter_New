import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import '../../../config/routes/app_routes.dart';
import '../../../core/constants/app_theme.dart';
import '../../providers/orders_provider.dart';
import '../../providers/dashboard_provider.dart';
import '../../../data/models/order_models.dart';
import '../../widgets/custom_loader_widget.dart';
import 'widgets/custom_confirm_dialog.dart';
import 'widgets/custom_success_dialog.dart';
import 'widgets/custom_pdf_dialog.dart';
import '../../../core/utils/common_methods.dart';

class OrderDetailsScreen extends StatefulWidget {
  final OrderHistoryResult order;
  const OrderDetailsScreen({super.key, required this.order});

  @override
  State<OrderDetailsScreen> createState() => _OrderDetailsScreenState();
}

class _OrderDetailsScreenState extends State<OrderDetailsScreen> {
  String _formatTime(String? dateStr) {
    if (dateStr == null || !dateStr.contains(" ")) return "";
    try {
      final parts = dateStr.split(" ")[1].split(":");
      if (parts.length >= 2) {
        int hour = int.parse(parts[0]);
        int minute = int.parse(parts[1]);
        String period = hour >= 12 ? "PM" : "AM";
        if (hour > 12) hour -= 12;
        if (hour == 0) hour = 12;
        String minStr = minute.toString().padLeft(2, '0');
        return "$hour:$minStr $period";
      }
    } catch (_) {}
    return dateStr.split(" ")[1];
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<OrdersProvider>().fetchOrderDetails(
            orderId: widget.order.orderId.toString(),
          );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Order Details",
            style: TextStyle(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryColor,
                fontSize: 18.sp)),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 1.0,
        iconTheme: IconThemeData(color: AppTheme.primaryColor),
      ),
      body: Stack(
        children: [
          Consumer<OrdersProvider>(
            builder: (context, provider, child) {
              if (provider.isLoading && provider.orderDetails == null) {
                return const SizedBox.shrink(); // Overlay handles loading
              }
              if (provider.orderDetails == null) {
                return const Center(child: Text("Failed to load details"));
              }
              return SingleChildScrollView(
                padding: EdgeInsets.all(CommonMethods.safeSize(16.w)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildSummaryCard(),
                    SizedBox(height: CommonMethods.safeSize(16.h)),

                    // Item Details Header
                    Text(
                      "Item Details",
                      style: TextStyle(
                          fontSize: CommonMethods.safeSize(15.sp, defaultValue: 15),
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryColor),
                    ),
                    Divider(color: Colors.grey[300]),

                    _buildSupplierDetails(provider.orderDetails!.results),

                    _buildTotalsSection(),
                    SizedBox(height: CommonMethods.safeSize(16.h)),

                    _buildAddressDetailsCard(),
                    SizedBox(height: CommonMethods.safeSize(10.h)),

                    _buildPaymentDetailsCard(),
                    SizedBox(height: CommonMethods.safeSize(16.h)),

                    _buildActionButtons(),
                    SizedBox(height: CommonMethods.safeSize(30.h)),
                  ],
                ),
              );
            },
          ),
          Consumer<OrdersProvider>(
            builder: (context, provider, child) {
              if (provider.isLoading) {
                return Container(
                  color: Colors.black54,
                  child: Center(
                    child: SizedBox(
                      width: CommonMethods.safeSize(100.w),
                      height: CommonMethods.safeSize(100.w),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          CustomLoaderWidget(size: CommonMethods.safeSize(100.w)),
                          Text(
                            "Please Wait",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: AppTheme.primaryColor,
                              fontSize: CommonMethods.safeSize(13.sp, defaultValue: 13),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard() {
    final isCancelled = widget.order.orderStatus?.toLowerCase() == "cancelled";
    final statusColor =
        isCancelled ? AppTheme.redColor : const Color(0xFF28A745);
    final statusIcon = isCancelled ? Icons.cancel : Icons.check_circle;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Order ID : #${widget.order.refNo}",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: AppTheme.primaryColor,
                        fontSize: 14.sp)),
                Row(
                  children: [
                    Text(widget.order.orderStatus ?? "",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: statusColor,
                            fontSize: 13.sp)),
                    SizedBox(width: 4.w),
                    Icon(statusIcon, color: statusColor, size: 16.sp),
                  ],
                ),
              ],
            ),
          ),
          Divider(color: Colors.grey[300], height: 1),
          Padding(
            padding: EdgeInsets.all(12.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSummaryRow("Order Date :",
                    widget.order.orderDate?.split(" ")[0] ?? ""),
                SizedBox(height: 8.h),
                _buildSummaryRow(
                    "Order Time :", _formatTime(widget.order.orderDate)),
                SizedBox(height: 8.h),
                _buildSummaryRow(
                    "Order Notes :",
                    widget.order.remarks != null &&
                            widget.order.remarks!.isNotEmpty
                        ? widget.order.remarks!
                        : ""),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 90.w,
          child: Text(label,
              style: TextStyle(
                  color: Colors.grey[700],
                  fontWeight: FontWeight.bold,
                  fontSize: 12.sp)),
        ),
        Expanded(
          child: Text(value,
              textAlign: TextAlign.right,
              style: TextStyle(
                  color: AppTheme.primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 13.sp)),
        ),
      ],
    );
  }

  Widget _buildSupplierDetails(List<OrderDetailResult>? results) {
    if (results == null || results.isEmpty) return const SizedBox.shrink();

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: results.length,
      itemBuilder: (context, index) {
        final supplier = results[index];
        return Container(
          margin: EdgeInsets.only(bottom: 12.h),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.grey[300]!),
            borderRadius: BorderRadius.circular(4.r),
          ),
          child: Column(
            children: [
              // Blue Supplier Header
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                decoration: BoxDecoration(
                  color: const Color(0xFF1358D4), // exact blue from screenshot
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(3.r)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      supplier.brandName ?? "Supplier",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14.sp),
                    ),
                    Consumer<DashboardProvider>(
                      builder: (context, dashboard, child) {
                        final bool showStatus = 
                            dashboard.profileResponse?.results?.firstOrNull?.showSupplierStatus == "Yes";
                        if (!showStatus) return const SizedBox.shrink();

                        final String statusText = 
                            widget.order.orderStatus?.toLowerCase() == "cancelled"
                                ? "Cancelled"
                                : supplier.supplierStatus ?? "";

                        return Padding(
                          padding: EdgeInsets.only(top: 4.h),
                          child: RichText(
                            text: TextSpan(
                              text: "Supplier Status : ",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13.sp),
                              children: [
                                TextSpan(
                                  text: statusText,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              // Products list
              ...(supplier.products ?? []).map((p) => Padding(
                    padding: EdgeInsets.all(12.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          p.productName ?? "",
                          style: TextStyle(
                              color: const Color(0xFF144BAB),
                              fontWeight: FontWeight.bold,
                              fontSize: 13.sp),
                        ),
                        SizedBox(height: 4.h),
                        Text(
                          CommonMethods.setPriceFormatString(p.salePrice),
                          style: TextStyle(
                              color: Colors.grey[600], fontSize: 12.sp),
                        ),
                        SizedBox(height: 8.h),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Qty : ${p.quantity}",
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12.sp),
                            ),
                            Text(
                              "Total : ${CommonMethods.setPriceFormatString(p.totalAmount)}",
                              style: TextStyle(
                                  color: const Color(0xFF144BAB),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12.sp),
                            ),
                          ],
                        ),
                        SizedBox(height: 8.h),
                        Consumer<DashboardProvider>(
                          builder: (context, dashboard, child) {
                            final bool showSoldAs = dashboard
                                    .profileResponse?.results?[0]?.showSoldAs ==
                                "Yes";
                            if (!showSoldAs) return const SizedBox.shrink();

                            return Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                RichText(
                                  text: TextSpan(
                                    text: "Sold As : ",
                                    style: TextStyle(
                                        color: Colors.black87,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12.sp),
                                    children: [
                                      TextSpan(
                                        text: p.soldAs ?? "",
                                        style: TextStyle(
                                            color: const Color(0xFF144BAB)),
                                      ),
                                    ],
                                  ),
                                ),
                                RichText(
                                  text: TextSpan(
                                    text: "Ordered As : ",
                                    style: TextStyle(
                                        color: Colors.black87,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12.sp),
                                    children: [
                                      TextSpan(
                                        text: p.orderedAs ?? "",
                                        style: TextStyle(
                                            color: const Color(0xFF144BAB)),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                  )),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTotalsSection() {
    double shippingVal = (double.tryParse(widget.order.deliveryCharge ?? '0') ?? 0) + 
                         (double.tryParse(widget.order.deliveryLocationCharge ?? '0') ?? 0);
    double gstVal = (double.tryParse(widget.order.deliveryChargeGst ?? '0') ?? 0) + 
                    (double.tryParse(widget.order.gst ?? '0') ?? 0);

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 8.h),
      child: Column(
        children: [
          _buildTotalRow("Sub Total :", widget.order.subTotal),
          SizedBox(height: 6.h),
          _buildTotalRow("Shipping :", shippingVal.toStringAsFixed(2)),
          if (gstVal > 0) ...[
            SizedBox(height: 6.h),
            _buildTotalRow("GST :", gstVal.toStringAsFixed(2)),
          ],
          SizedBox(height: 6.h),
          _buildTotalRow("Grand Total", widget.order.orderAmount,
              isGrandTotal: true),
          Align(
            alignment: Alignment.centerLeft,
            child: Text("Inc. GST :",
                style: TextStyle(
                    color: Colors.grey[700],
                    fontWeight: FontWeight.bold,
                    fontSize: 11.sp)),
          ),
          SizedBox(height: 8.h),
          Divider(color: Colors.grey[300]),
        ],
      ),
    );
  }

  Widget _buildTotalRow(String label, String? val,
      {bool isGrandTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[700],
            fontWeight: FontWeight.bold,
            fontSize: isGrandTotal ? 13.sp : 12.sp,
          ),
        ),
        Text(
          CommonMethods.setPriceFormatString(val),
          style: TextStyle(
            color: const Color(0xFF144BAB),
            fontWeight: FontWeight.bold,
            fontSize: isGrandTotal ? 14.sp : 13.sp,
          ),
        ),
      ],
    );
  }

  Widget _buildAddressDetailsCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey[400]!),
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: ExpansionTile(
        shape: const Border(), // Remove default borders of ExpansionTile
        collapsedShape: const Border(),
        iconColor: AppTheme.primaryColor,
        collapsedIconColor: AppTheme.primaryColor,
        title: Text("Address Details",
            style: TextStyle(
                color: AppTheme.primaryColor,
                fontWeight: FontWeight.bold,
                fontSize: 14.sp)),
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.only(
                left: 16.w, right: 16.w, bottom: 16.h, top: 4.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Billing Address :",
                    style: TextStyle(
                        color: Colors.grey[800],
                        fontWeight: FontWeight.bold,
                        fontSize: 12.sp)),
                SizedBox(height: 4.h),
                Text(
                  widget.order.billingAddress
                          ?.replaceAll(
                              RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
                          .replaceAll(", ", "\n") ??
                      "",
                  style: TextStyle(
                      color: const Color(0xFF144BAB),
                      fontWeight: FontWeight.bold,
                      fontSize: 12.sp,
                      height: 1.4),
                ),
                SizedBox(height: 16.h),
                Text("Shipping Address :",
                    style: TextStyle(
                        color: Colors.grey[800],
                        fontWeight: FontWeight.bold,
                        fontSize: 12.sp)),
                SizedBox(height: 4.h),
                Text(
                  widget.order.deliveryAddress
                          ?.replaceAll(
                              RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
                          .replaceAll(", ", "\n") ??
                      "",
                  style: TextStyle(
                      color: const Color(0xFF144BAB),
                      fontWeight: FontWeight.bold,
                      fontSize: 12.sp,
                      height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentDetailsCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey[400]!),
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: ExpansionTile(
        shape: const Border(),
        collapsedShape: const Border(),
        iconColor: AppTheme.primaryColor,
        collapsedIconColor: AppTheme.primaryColor,
        title: Text("Payment Details",
            style: TextStyle(
                color: AppTheme.primaryColor,
                fontWeight: FontWeight.bold,
                fontSize: 14.sp)),
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.only(left: 16.w, right: 16.w, bottom: 16.h),
            child: Row(
              children: [
                Text("Payment Method : ",
                    style: TextStyle(
                        color: Colors.grey[800],
                        fontWeight: FontWeight.bold,
                        fontSize: 12.sp)),
                Text(
                  widget.order.paymentType ?? "Cash on Delivery",
                  style: TextStyle(
                      color: const Color(0xFF144BAB),
                      fontWeight: FontWeight.bold,
                      fontSize: 12.sp),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    final dashboardProvider = context.read<DashboardProvider>();
    final allowCancel = dashboardProvider.profileResponse?.results?.firstOrNull?.allowCustomerToCancelOrder == "Yes";
    final allowReplicate = dashboardProvider.profileResponse?.results?.firstOrNull?.allowCustomersToReplicateOrders == "Yes";
    final allowReorder = dashboardProvider.profileResponse?.results?.firstOrNull?.allowCustomerToReorderSameProducts == "Yes";

    final bool isCancelled =
        widget.order.orderStatus?.toLowerCase() == "cancelled";
    final bool showCancel = allowCancel && 
        (widget.order.orderStatus?.toLowerCase() == "received" || widget.order.orderStatus?.toLowerCase() == "processing");

    return Column(
      children: [
        Row(
          children: [
            if (allowReorder)
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(right: allowReplicate ? 10.w : 0),
                  child: _buildActionButton(
                      "Re-Order", const Color(0xFFFDB833), () => _handleReorder()),
                ),
              ),
            if (allowReplicate)
              Expanded(
                child: _buildActionButton("Duplicate Order",
                    const Color(0xFF23428E), () => _handleDuplicate()),
              ),
          ],
        ),
        SizedBox(height: 10.h),
        Row(
          children: [
            if (showCancel)
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(right: 10.w),
                  child: _buildActionButton("Cancel Order",
                      const Color(0xFFE91E63), () => _handleCancel()),
                ),
              ),
            Expanded(
              child: _buildActionButton("Order Confirmation",
                  const Color(0xFF00CBEF), () => _handleOrderConfirmation()),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionButton(String label, Color color, VoidCallback onTap) {
    return SizedBox(
      height: 48.h,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.r)),
          elevation: 0,
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 12.sp),
        ),
      ),
    );
  }

  void _handleOrderConfirmation() {
    if (widget.order.pdfFile != null && widget.order.pdfFile!.isNotEmpty) {
      showDialog(
        context: context,
        builder: (ctx) => CustomPdfDialog(
          pdfUrl: widget.order.pdfFile!,
          orderId: widget.order.refNo ?? "Unknown",
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Invoice not available yet.")));
    }
  }

  void _handleReorder() async {
    final dashboardProvider = context.read<DashboardProvider>();
    final contentText = dashboardProvider.profileResponse?.results?.firstOrNull?.reorderConfirmationText ??
        "You are Re-Ordering the same products.\nProducts price will update with the current price.";

    final bool? confirm = await _showConfirmDialog(
      title: "Re-Order Confirmation",
      orderId: widget.order.refNo ?? "",
      content: contentText,
      confirmText: "Re-Order",
      confirmColor: AppTheme.secondaryColor,
    );

    if (confirm == true && mounted) {
      final ordersProvider = context.read<OrdersProvider>();
      final success = await ordersProvider.reorderOrder(
        oldOrderId: widget.order.orderId.toString(),
      );
      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Added all products to cart")));
        while (Navigator.canPop(context)) {
          Navigator.pop(context);
        }
        context.push(AppRoutes.checkout, extra: {'initialStep': 0});
      }
    }
  }

  void _handleDuplicate() async {
    final dashboardProvider = context.read<DashboardProvider>();
    final contentText = dashboardProvider.profileResponse?.results?.firstOrNull?.replicateOrderConfirmationText ??
        "Do you want to duplicate this order?";

    final bool? confirm = await _showConfirmDialog(
      title: "Duplicate Order Confirmation",
      orderId: widget.order.refNo ?? "",
      content: contentText,
      confirmText: "Duplicate",
      confirmColor: AppTheme.primaryColor,
    );

    if (confirm == true && mounted) {
      final ordersProvider = context.read<OrdersProvider>();
      final newOrderId = await ordersProvider.duplicateOrder(
        oldOrderId: widget.order.orderId.toString(),
      );
      if (newOrderId != null && mounted) {
        _showSuccessDialog("Order Submitted Successfully", "#$newOrderId");
      }
    }
  }

  void _handleCancel() async {
    final bool? confirm = await _showConfirmDialog(
      title: "Cancel Order Confirmation",
      orderId: widget.order.refNo ?? "",
      content: "Do you want to cancel this order?",
      confirmText: "Cancel Order",
      confirmColor: AppTheme.redColor,
    );

    if (confirm == true && mounted) {
      final ordersProvider = context.read<OrdersProvider>();
      final success = await ordersProvider.cancelOrder(
        orderId: widget.order.orderId.toString(),
      );
      if (success && mounted) {
        Navigator.pop(context);
      }
    }
  }

  Future<bool?> _showConfirmDialog({
    required String title,
    required String orderId,
    required String content,
    required String confirmText,
    required Color confirmColor,
  }) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => CustomConfirmDialog(
        title: title,
        orderId: orderId,
        content: content,
        confirmText: confirmText,
        confirmColor: confirmColor,
      ),
    );
  }

  void _showSuccessDialog(String title, String orderId) {
    showDialog(
      context: context,
      builder: (ctx) => CustomSuccessDialog(
        title: title,
        orderId: orderId,
        content: "",
      ),
    );
  }
}
